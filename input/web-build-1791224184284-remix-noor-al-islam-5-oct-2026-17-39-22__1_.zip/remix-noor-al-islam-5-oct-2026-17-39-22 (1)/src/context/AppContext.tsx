import React, { createContext, useContext, useEffect, useState } from 'react';

export type TabType =
  | 'home'
  | 'adhkar'
  | 'duas'
  | 'names'
  | 'hadith'
  | 'tasbih'
  | 'prayer'
  | 'qibla'
  | 'calendar'
  | 'favorites'
  | 'search'
  | 'settings'
  | 'about';

export interface FavoriteItem {
  id: string;
  type: 'dhikr' | 'dua' | 'hadith' | 'name';
  title: string;
  arabic: string;
  source?: string;
  extra?: string;
}

export interface UserLocation {
  name: string;
  country?: string;
  lat: number;
  lng: number;
  isGps: boolean;
  timezoneOffset?: number;
}

interface AppContextType {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  targetCategory?: string;
  setTargetCategory: (cat?: string) => void;
  
  // Theme & Font
  isDarkMode: boolean;
  setIsDarkMode: (dark: boolean) => void;
  fontSize: 'sm' | 'md' | 'lg' | 'xl';
  setFontSize: (size: 'sm' | 'md' | 'lg' | 'xl') => void;
  
  // Audio & Vibration
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  vibrationEnabled: boolean;
  setVibrationEnabled: (enabled: boolean) => void;

  // Prayer & Calendar Settings
  hijriAdjustment: number;
  setHijriAdjustment: (offset: number) => void;
  prayerMethod: string;
  setPrayerMethod: (method: string) => void;
  asrMethod: 'standard' | 'hanafi';
  setAsrMethod: (m: 'standard' | 'hanafi') => void;
  userLocation: UserLocation;
  setUserLocation: (loc: UserLocation) => void;
  requestGpsLocation: () => Promise<boolean>;

  // Favorites
  favorites: FavoriteItem[];
  toggleFavorite: (item: FavoriteItem) => void;
  isFavorite: (id: string) => boolean;

  // Tasbih
  tasbihCount: number;
  tasbihTarget: number;
  tasbihTotal: number;
  tasbihLaps: number;
  tasbihDhikr: string;
  incrementTasbih: () => void;
  resetTasbihCurrent: () => void;
  resetTasbihAll: () => void;
  setTasbihTarget: (target: number) => void;
  setTasbihDhikr: (dhikr: string) => void;

  // Global Search state
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const DEFAULT_LOCATION: UserLocation = {
  name: 'مكة المكرمة',
  country: 'السعودية',
  lat: 21.4225,
  lng: 39.8262,
  isGps: false,
  timezoneOffset: 3
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [targetCategory, setTargetCategory] = useState<string | undefined>(undefined);

  // Settings from localStorage
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('noor_theme');
    if (saved) return saved === 'dark';
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  const [fontSize, setFontSize] = useState<'sm' | 'md' | 'lg' | 'xl'>(() => {
    return (localStorage.getItem('noor_font_size') as 'sm' | 'md' | 'lg' | 'xl') || 'md';
  });

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('noor_sound');
    return saved !== null ? saved === 'true' : true;
  });

  const [vibrationEnabled, setVibrationEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('noor_vibration');
    return saved !== null ? saved === 'true' : true;
  });

  const [hijriAdjustment, setHijriAdjustment] = useState<number>(() => {
    const saved = localStorage.getItem('noor_hijri_adj');
    return saved ? parseInt(saved, 10) : 0;
  });

  const [prayerMethod, setPrayerMethod] = useState<string>(() => {
    return localStorage.getItem('noor_prayer_method') || 'makkah';
  });

  const [asrMethod, setAsrMethod] = useState<'standard' | 'hanafi'>(() => {
    return (localStorage.getItem('noor_asr_method') as 'standard' | 'hanafi') || 'standard';
  });

  const [userLocation, setUserLocation] = useState<UserLocation>(() => {
    const saved = localStorage.getItem('noor_location');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // Fallback
      }
    }
    return DEFAULT_LOCATION;
  });

  // Favorites
  const [favorites, setFavorites] = useState<FavoriteItem[]>(() => {
    const saved = localStorage.getItem('noor_favorites');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // Fallback
      }
    }
    return [];
  });

  // Tasbih state
  const [tasbihCount, setTasbihCount] = useState<number>(() => {
    return parseInt(localStorage.getItem('noor_tasbih_count') || '0', 10);
  });
  const [tasbihTarget, setTasbihTargetState] = useState<number>(() => {
    return parseInt(localStorage.getItem('noor_tasbih_target') || '33', 10);
  });
  const [tasbihTotal, setTasbihTotal] = useState<number>(() => {
    return parseInt(localStorage.getItem('noor_tasbih_total') || '0', 10);
  });
  const [tasbihLaps, setTasbihLaps] = useState<number>(() => {
    return parseInt(localStorage.getItem('noor_tasbih_laps') || '0', 10);
  });
  const [tasbihDhikr, setTasbihDhikrState] = useState<string>(() => {
    return localStorage.getItem('noor_tasbih_dhikr') || 'سُبْحَانَ اللَّهِ';
  });

  const [searchQuery, setSearchQuery] = useState<string>('');

  // Sync dark mode class to html element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('noor_theme', isDarkMode ? 'dark' : 'light');
  }, [isDarkMode]);

  // Sync settings
  useEffect(() => {
    localStorage.setItem('noor_font_size', fontSize);
  }, [fontSize]);

  useEffect(() => {
    localStorage.setItem('noor_sound', soundEnabled.toString());
  }, [soundEnabled]);

  useEffect(() => {
    localStorage.setItem('noor_vibration', vibrationEnabled.toString());
  }, [vibrationEnabled]);

  useEffect(() => {
    localStorage.setItem('noor_hijri_adj', hijriAdjustment.toString());
  }, [hijriAdjustment]);

  useEffect(() => {
    localStorage.setItem('noor_prayer_method', prayerMethod);
  }, [prayerMethod]);

  useEffect(() => {
    localStorage.setItem('noor_asr_method', asrMethod);
  }, [asrMethod]);

  useEffect(() => {
    localStorage.setItem('noor_location', JSON.stringify(userLocation));
  }, [userLocation]);

  useEffect(() => {
    localStorage.setItem('noor_favorites', JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem('noor_tasbih_count', tasbihCount.toString());
    localStorage.setItem('noor_tasbih_target', tasbihTarget.toString());
    localStorage.setItem('noor_tasbih_total', tasbihTotal.toString());
    localStorage.setItem('noor_tasbih_laps', tasbihLaps.toString());
    localStorage.setItem('noor_tasbih_dhikr', tasbihDhikr);
  }, [tasbihCount, tasbihTarget, tasbihTotal, tasbihLaps, tasbihDhikr]);

  // Favorite toggler
  const toggleFavorite = (item: FavoriteItem) => {
    setFavorites(prev => {
      const exists = prev.some(f => f.id === item.id);
      if (exists) {
        return prev.filter(f => f.id !== item.id);
      } else {
        return [item, ...prev];
      }
    });
  };

  const isFavorite = (id: string) => favorites.some(f => f.id === id);

  // Tasbih actions
  const incrementTasbih = () => {
    const nextCount = tasbihCount + 1;
    const nextTotal = tasbihTotal + 1;

    if (tasbihTarget > 0 && nextCount >= tasbihTarget) {
      setTasbihCount(0);
      setTasbihLaps(prev => prev + 1);
    } else {
      setTasbihCount(nextCount);
    }
    setTasbihTotal(nextTotal);
  };

  const resetTasbihCurrent = () => {
    setTasbihCount(0);
  };

  const resetTasbihAll = () => {
    setTasbihCount(0);
    setTasbihLaps(0);
    setTasbihTotal(0);
  };

  const setTasbihTarget = (target: number) => {
    setTasbihTargetState(target);
    setTasbihCount(0);
  };

  const setTasbihDhikr = (dhikr: string) => {
    setTasbihDhikrState(dhikr);
    setTasbihCount(0);
  };

  // Request GPS
  const requestGpsLocation = async (): Promise<boolean> => {
    if (!navigator.geolocation) return false;
    return new Promise((resolve) => {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const offsetHours = -new Date().getTimezoneOffset() / 60;
          setUserLocation({
            name: 'موقعي الحالي (GPS)',
            country: 'إحداثيات الجهاز',
            lat: latitude,
            lng: longitude,
            isGps: true,
            timezoneOffset: offsetHours
          });
          resolve(true);
        },
        () => {
          resolve(false);
        },
        { enableHighAccuracy: true, timeout: 8000 }
      );
    });
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        targetCategory,
        setTargetCategory,
        isDarkMode,
        setIsDarkMode,
        fontSize,
        setFontSize,
        soundEnabled,
        setSoundEnabled,
        vibrationEnabled,
        setVibrationEnabled,
        hijriAdjustment,
        setHijriAdjustment,
        prayerMethod,
        setPrayerMethod,
        asrMethod,
        setAsrMethod,
        userLocation,
        setUserLocation,
        requestGpsLocation,
        favorites,
        toggleFavorite,
        isFavorite,
        tasbihCount,
        tasbihTarget,
        tasbihTotal,
        tasbihLaps,
        tasbihDhikr,
        incrementTasbih,
        resetTasbihCurrent,
        resetTasbihAll,
        setTasbihTarget,
        setTasbihDhikr,
        searchQuery,
        setSearchQuery,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
