export const KAABA_COORDS = {
  lat: 21.422487,
  lng: 39.826206,
};

export interface QiblaInfo {
  bearing: number; // in degrees 0-360 clockwise from North
  distanceKm: number; // in km to Kaaba
}

function toRad(deg: number): number {
  return (deg * Math.PI) / 180;
}

function toDeg(rad: number): number {
  return (rad * 180) / Math.PI;
}

/**
 * Calculates the exact Qibla bearing and distance from any coordinates on earth
 */
export function calculateQibla(latitude: number, longitude: number): QiblaInfo {
  const phi1 = toRad(latitude);
  const phi2 = toRad(KAABA_COORDS.lat);
  const deltaLambda = toRad(KAABA_COORDS.lng - longitude);

  const y = Math.sin(deltaLambda) * Math.cos(phi2);
  const x = Math.cos(phi1) * Math.sin(phi2) - Math.sin(phi1) * Math.cos(phi2) * Math.cos(deltaLambda);
  
  let bearing = toDeg(Math.atan2(y, x));
  bearing = (bearing + 360) % 360;

  // Haversine formula for distance
  const R = 6371; // Earth radius in km
  const deltaPhi = toRad(KAABA_COORDS.lat - latitude);
  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distanceKm = Math.round(R * c);

  return {
    bearing: Math.round(bearing * 10) / 10,
    distanceKm
  };
}

export function getCompassDirectionArabic(degrees: number): string {
  const directions = [
    { name: 'شمال', min: 337.5, max: 360 },
    { name: 'شمال', min: 0, max: 22.5 },
    { name: 'شمال شرقي', min: 22.5, max: 67.5 },
    { name: 'شرق', min: 67.5, max: 112.5 },
    { name: 'جنوب شرقي', min: 112.5, max: 157.5 },
    { name: 'جنوب', min: 157.5, max: 202.5 },
    { name: 'جنوب غربي', min: 202.5, max: 247.5 },
    { name: 'غرب', min: 247.5, max: 292.5 },
    { name: 'شمال غربي', min: 292.5, max: 337.5 },
  ];

  const found = directions.find(d => degrees >= d.min && degrees < d.max);
  return found ? found.name : 'شمال';
}
