export interface CalculationMethod {
  id: string;
  name: string;
  fajrAngle: number;
  ishaAngle?: number;
  ishaInterval?: number; // in minutes after Maghrib
}

export const CALCULATION_METHODS: Record<string, CalculationMethod> = {
  makkah: {
    id: 'makkah',
    name: 'أم القرى (مكة المكرمة)',
    fajrAngle: 18.5,
    ishaInterval: 90
  },
  mwl: {
    id: 'mwl',
    name: 'رابطة العالم الإسلامي (MWL)',
    fajrAngle: 18.0,
    ishaAngle: 17.0
  },
  egypt: {
    id: 'egypt',
    name: 'الهيئة المصرية العامة للمساحة',
    fajrAngle: 19.5,
    ishaAngle: 17.5
  },
  isna: {
    id: 'isna',
    name: 'الجمعية الإسلامية لأمريكا الشمالية (ISNA)',
    fajrAngle: 15.0,
    ishaAngle: 15.0
  },
  karachi: {
    id: 'karachi',
    name: 'جامعة العلوم الإسلامية بكراتشي',
    fajrAngle: 18.0,
    ishaAngle: 18.0
  }
};

export interface CityPreset {
  name: string;
  country: string;
  lat: number;
  lng: number;
  timezoneOffset: number; // in hours from UTC
  defaultMethod: string;
}

export const POPULAR_CITIES: CityPreset[] = [
  { name: 'مكة المكرمة', country: 'السعودية', lat: 21.4225, lng: 39.8262, timezoneOffset: 3, defaultMethod: 'makkah' },
  { name: 'المدينة المنورة', country: 'السعودية', lat: 24.5247, lng: 39.5692, timezoneOffset: 3, defaultMethod: 'makkah' },
  { name: 'الرياض', country: 'السعودية', lat: 24.7136, lng: 46.6753, timezoneOffset: 3, defaultMethod: 'makkah' },
  { name: 'الدار البيضاء', country: 'المغرب', lat: 33.5731, lng: -7.5898, timezoneOffset: 1, defaultMethod: 'mwl' },
  { name: 'الرباط', country: 'المغرب', lat: 34.0209, lng: -6.8416, timezoneOffset: 1, defaultMethod: 'mwl' },
  { name: 'القاهرة', country: 'مصر', lat: 30.0444, lng: 31.2357, timezoneOffset: 2, defaultMethod: 'egypt' },
  { name: 'دبي', country: 'الإمارات', lat: 25.2048, lng: 55.2708, timezoneOffset: 4, defaultMethod: 'makkah' },
  { name: 'القدس الشريف', country: 'فلسطين', lat: 31.7683, lng: 35.2137, timezoneOffset: 3, defaultMethod: 'mwl' },
  { name: 'عمّان', country: 'الأردن', lat: 31.9454, lng: 35.9284, timezoneOffset: 3, defaultMethod: 'mwl' },
  { name: 'الجزائر العاصمة', country: 'الجزائر', lat: 36.7538, lng: 3.0588, timezoneOffset: 1, defaultMethod: 'mwl' },
  { name: 'تونس العاصمة', country: 'تونس', lat: 36.8065, lng: 10.1815, timezoneOffset: 1, defaultMethod: 'mwl' },
  { name: 'بغداد', country: 'العراق', lat: 33.3152, lng: 44.3661, timezoneOffset: 3, defaultMethod: 'mwl' },
  { name: 'إسطنبول', country: 'تركيا', lat: 41.0082, lng: 28.9784, timezoneOffset: 3, defaultMethod: 'mwl' },
  { name: 'باريس', country: 'فرنسا', lat: 48.8566, lng: 2.3522, timezoneOffset: 2, defaultMethod: 'mwl' },
  { name: 'لندن', country: 'المملكة المتحدة', lat: 51.5074, lng: -0.1278, timezoneOffset: 1, defaultMethod: 'mwl' },
];

export interface PrayerTimesResult {
  fajr: string;
  sunrise: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
  nextPrayer: {
    name: string;
    key: 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha';
    timeStr: string;
    timeRemaining: string; // e.g. "02:45:10"
    secondsRemaining: number;
  };
}

// Math helper functions for astronomical calculations
function degToRad(deg: number): number {
  return (deg * Math.PI) / 180.0;
}

function radToDeg(rad: number): number {
  return (rad * 180.0) / Math.PI;
}

function sinDeg(deg: number): number {
  return Math.sin(degToRad(deg));
}

function cosDeg(deg: number): number {
  return Math.cos(degToRad(deg));
}

function tanDeg(deg: number): number {
  return Math.tan(degToRad(deg));
}

function fixHour(hour: number): number {
  let a = hour - 24.0 * Math.floor(hour / 24.0);
  return a < 0 ? a + 24.0 : a;
}

function fixAngle(a: number): number {
  let b = a - 360.0 * Math.floor(a / 360.0);
  return b < 0 ? b + 360.0 : b;
}

// Astronomical calculation of Sun Position
function getSunPosition(julianDate: number): { declination: number; equationOfTime: number } {
  const d = julianDate - 2451545.0;
  const g = fixAngle(357.529 + 0.98560028 * d);
  const q = fixAngle(280.459 + 0.98564736 * d);
  const l = fixAngle(q + 1.915 * sinDeg(g) + 0.02 * sinDeg(2 * g));

  const e = 23.439 - 0.00000036 * d;
  const declination = radToDeg(Math.asin(sinDeg(e) * sinDeg(l)));
  
  let ra = radToDeg(Math.atan2(cosDeg(e) * sinDeg(l), cosDeg(l))) / 15.0;
  ra = fixHour(ra);
  
  const equationOfTime = q / 15.0 - ra;
  return { declination, equationOfTime };
}

function getJulianDate(year: number, month: number, day: number): number {
  if (month <= 2) {
    year -= 1;
    month += 12;
  }
  const A = Math.floor(year / 100);
  const B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (year + 4716)) + Math.floor(30.6001 * (month + 1)) + day + B - 1524.5;
}

/**
 * 100% Offline Calculation of Daily Prayer Times
 */
export function calculatePrayerTimes(
  date: Date,
  lat: number,
  lng: number,
  timezoneOffset?: number,
  methodId = 'makkah',
  asrJuristic: 'standard' | 'hanafi' = 'standard'
): PrayerTimesResult {
  const method = CALCULATION_METHODS[methodId] || CALCULATION_METHODS.makkah;
  const tz = timezoneOffset !== undefined ? timezoneOffset : -date.getTimezoneOffset() / 60;

  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();

  const jd = getJulianDate(year, month, day);
  const { declination, equationOfTime } = getSunPosition(jd);

  // Solar noon (Dhuhr)
  const noon = fixHour(12 + tz - lng / 15.0 - equationOfTime);

  // Helper to compute hour angle for a given altitude angle
  function computeHourAngle(angle: number): number {
    const latRad = degToRad(lat);
    const decRad = degToRad(declination);
    const angRad = degToRad(angle);

    const cosH = (Math.sin(angRad) - Math.sin(latRad) * Math.sin(decRad)) / (Math.cos(latRad) * Math.cos(decRad));
    if (cosH > 1 || cosH < -1) {
      return 0; // extreme latitude condition
    }
    return radToDeg(Math.acos(cosH)) / 15.0;
  }

  // Fajr
  const fajrHourAngle = computeHourAngle(-method.fajrAngle);
  const fajrTime = fixHour(noon - fajrHourAngle);

  // Sunrise (Sun altitude = -0.833° for atmospheric refraction)
  const sunriseHourAngle = computeHourAngle(-0.8333);
  const sunriseTime = fixHour(noon - sunriseHourAngle);

  // Dhuhr: noon + ~2-4 minutes safety margin
  const dhuhrTime = fixHour(noon + 0.05);

  // Asr
  const asrFactor = asrJuristic === 'hanafi' ? 2 : 1;
  const asrAlt = radToDeg(Math.atan(1.0 / (asrFactor + Math.tan(degToRad(Math.abs(lat - declination))))));
  const asrHourAngle = computeHourAngle(asrAlt);
  const asrTime = fixHour(noon + asrHourAngle);

  // Maghrib (Sunset altitude = -0.8333°)
  const sunsetHourAngle = sunriseHourAngle;
  const maghribTime = fixHour(noon + sunsetHourAngle);

  // Isha
  let ishaTime: number;
  if (method.ishaInterval) {
    ishaTime = fixHour(maghribTime + method.ishaInterval / 60.0);
  } else {
    const ishaAngle = method.ishaAngle || 17.0;
    const ishaHourAngle = computeHourAngle(-ishaAngle);
    ishaTime = fixHour(noon + ishaHourAngle);
  }

  function formatTime(hours: number): string {
    const h = Math.floor(hours);
    const m = Math.floor((hours - h) * 60);
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
  }

  const times = {
    fajr: formatTime(fajrTime),
    sunrise: formatTime(sunriseTime),
    dhuhr: formatTime(dhuhrTime),
    asr: formatTime(asrTime),
    maghrib: formatTime(maghribTime),
    isha: formatTime(ishaTime),
  };

  // Find next prayer and calculate seconds remaining
  const currentHours = date.getHours() + date.getMinutes() / 60 + date.getSeconds() / 3600;

  const prayerSchedule: { key: 'fajr' | 'sunrise' | 'dhuhr' | 'asr' | 'maghrib' | 'isha'; name: string; hours: number }[] = [
    { key: 'fajr', name: 'الفجر', hours: fajrTime },
    { key: 'sunrise', name: 'الشروق', hours: sunriseTime },
    { key: 'dhuhr', name: 'الظهر', hours: dhuhrTime },
    { key: 'asr', name: 'العصر', hours: asrTime },
    { key: 'maghrib', name: 'المغرب', hours: maghribTime },
    { key: 'isha', name: 'العشاء', hours: ishaTime },
  ];

  let next = prayerSchedule.find(p => p.hours > currentHours);
  let nextDiffHours = 0;

  if (!next) {
    // next is Fajr tomorrow
    next = prayerSchedule[0];
    nextDiffHours = 24 - currentHours + next.hours;
  } else {
    nextDiffHours = next.hours - currentHours;
  }

  const totalSeconds = Math.max(0, Math.floor(nextDiffHours * 3600));
  const diffH = Math.floor(totalSeconds / 3600);
  const diffM = Math.floor((totalSeconds % 3600) / 60);
  const diffS = totalSeconds % 60;
  const timeRemaining = `${diffH.toString().padStart(2, '0')}:${diffM.toString().padStart(2, '0')}:${diffS.toString().padStart(2, '0')}`;

  return {
    ...times,
    nextPrayer: {
      key: next.key,
      name: next.name,
      timeStr: times[next.key],
      timeRemaining,
      secondsRemaining: totalSeconds
    }
  };
}
