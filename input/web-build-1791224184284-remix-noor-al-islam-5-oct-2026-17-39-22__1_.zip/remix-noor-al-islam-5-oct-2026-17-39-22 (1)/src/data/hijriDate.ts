export interface IslamicEvent {
  day: number;
  month: number; // 1 = Muharram, 12 = Dhul-Hijjah
  monthName: string;
  title: string;
  description: string;
}

export const ISLAMIC_EVENTS: IslamicEvent[] = [
  { day: 1, month: 1, monthName: 'محرم', title: 'رأس السنة الهجرية', description: 'بداية العام الهجري الجديد وذكرى هجرة النبي صلى الله عليه وسلم' },
  { day: 10, month: 1, monthName: 'محرم', title: 'يوم عاشوراء', description: 'يوم نجاة موسى عليه السلام وصيامه يكفر ذنوب سنة ماضية' },
  { day: 12, month: 3, monthName: 'ربيع الأول', title: 'المولد النبوي الشريف', description: 'ذكرى مولد خاتم الأنبياء والمرسلين محمد صلى الله عليه وسلم' },
  { day: 27, month: 7, monthName: 'رجب', title: 'الإسراء والمعراج', description: 'معجزة الإسراء والمعراج وفرض الصلوات الخمس في السماء' },
  { day: 15, month: 8, monthName: 'شعبان', title: 'ليلة النصف من شعبان', description: 'ليلة تحويل القبلة من المسجد الأقصى إلى المسجد الحرام' },
  { day: 1, month: 9, monthName: 'رمضان', title: 'أول أيام شهر رمضان المبارك', description: 'شهر الصيام والقرآن والرحمة والغفران' },
  { day: 17, month: 9, monthName: 'رمضان', title: 'ذكرى غزوة بدر الكبرى', description: 'يوم الفرقان يوم التقى الجمعان ونصر الله المؤمنين' },
  { day: 27, month: 9, monthName: 'رمضان', title: 'ليلة القدر (أرجى الليالي)', description: 'خير من ألف شهر تنزل الملائكة والروح فيها بإذن ربهم' },
  { day: 1, month: 10, monthName: 'شوال', title: 'عيد الفطر المبارك', description: 'جائزة الصائمين وفرحة إتمام شهر رمضان المبارك' },
  { day: 1, month: 12, monthName: 'ذو الحجة', title: 'عشر ذي الحجة', description: 'أفضل أيام الدنيا والعمل الصالح فيها أحب إلى الله تعالى' },
  { day: 8, month: 12, monthName: 'ذو الحجة', title: 'يوم التروية', description: 'بداية مناسك الحج وانطلاق الحجاج إلى مِنى' },
  { day: 9, month: 12, monthName: 'ذو الحجة', title: 'يوم عرفة العظيم', description: 'ركن الحج الأعظم، وصيامه لغير الحاج يكفر سنتين' },
  { day: 10, month: 12, monthName: 'ذو الحجة', title: 'عيد الأضحى المبارك', description: 'يوم النحر وذكرى فداء إسماعيل عليه السلام' },
  { day: 11, month: 12, monthName: 'ذو الحجة', title: 'أول أيام التشريق', description: 'أيام أكل وشرب وذكر لله تعالى وتكبير' },
];

export const HIJRI_MONTHS = [
  'محرم',
  'صفر',
  'ربيع الأول',
  'ربيع الآخر',
  'جمادى الأولى',
  'جمادى الآخرة',
  'رجب',
  'شعبان',
  'رمضان',
  'شوال',
  'ذو القعدة',
  'ذو الحجة'
];

export const ARABIC_DAYS = [
  'الأحد',
  'الإثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت'
];

export interface HijriDateResult {
  day: number;
  month: number; // 1-12
  monthName: string;
  year: number;
  dayName: string;
  formatted: string;
  gregorianFormatted: string;
  upcomingEvent?: IslamicEvent;
}

/**
 * Calculates Hijri Date with adjustment offset in days (-2, -1, 0, +1, +2)
 */
export function getHijriDate(date: Date = new Date(), adjustmentDays: number = 0): HijriDateResult {
  const adjustedDate = new Date(date.getTime() + adjustmentDays * 86400000);
  const dayName = ARABIC_DAYS[adjustedDate.getDay()];

  // Format Gregorian
  const gregDay = adjustedDate.getDate();
  const gregMonths = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  const gregorianFormatted = `${dayName}، ${gregDay} ${gregMonths[adjustedDate.getMonth()]} ${adjustedDate.getFullYear()} م`;

  let day = 1;
  let month = 1;
  let year = 1448;
  let monthName = HIJRI_MONTHS[0];

  try {
    const formatter = new Intl.DateTimeFormat('en-u-ca-islamic-umalqura-nu-latn', {
      day: 'numeric',
      month: 'numeric',
      year: 'numeric',
    });
    const parts = formatter.formatToParts(adjustedDate);
    const dayPart = parts.find(p => p.type === 'day');
    const monthPart = parts.find(p => p.type === 'month');
    const yearPart = parts.find(p => p.type === 'year');

    if (dayPart && monthPart && yearPart) {
      day = parseInt(dayPart.value, 10);
      month = parseInt(monthPart.value, 10);
      year = parseInt(yearPart.value, 10);
      monthName = HIJRI_MONTHS[month - 1] || 'محرم';
    }
  } catch {
    // Offline algorithmic fallback (Kuwaiti algorithm)
    const m = adjustedDate.getMonth() + 1;
    const y = adjustedDate.getFullYear();
    const d = adjustedDate.getDate();
    let jd = 0;
    if (m <= 2) {
      jd = Math.floor(365.25 * (y - 1)) + Math.floor(30.6001 * (m + 13)) + d - 679006;
    } else {
      jd = Math.floor(365.25 * y) + Math.floor(30.6001 * (m + 1)) + d - 679006;
    }
    const b = 0;
    const jd2 = jd + b;
    const z = jd2 - 429;
    const cyc = Math.floor(z / 10631);
    const zRem = z - 10631 * cyc;
    const j = Math.floor((zRem - 0.25) / 354.366);
    year = 30 * cyc + j + 1400;
    const rem2 = zRem - Math.floor(j * 354.366 + 0.5);
    month = Math.floor((rem2 + 28.5) / 29.5);
    if (month === 13) month = 12;
    day = Math.floor(rem2 - Math.floor((month - 1) * 29.5) + 1);
    monthName = HIJRI_MONTHS[month - 1] || 'محرم';
  }

  const formatted = `${dayName}، ${day} ${monthName} ${year} هـ`;

  // Check if today or upcoming event in this month
  const eventThisMonth = ISLAMIC_EVENTS.find(e => e.month === month && e.day >= day) ||
    ISLAMIC_EVENTS.find(e => (e.month === (month % 12) + 1));

  return {
    day,
    month,
    monthName,
    year,
    dayName,
    formatted,
    gregorianFormatted,
    upcomingEvent: eventThisMonth
  };
}
