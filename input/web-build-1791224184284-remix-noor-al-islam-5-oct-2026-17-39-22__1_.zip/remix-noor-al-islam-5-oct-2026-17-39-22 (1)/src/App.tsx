/**
 * Noor Al-Islam - نور الإسلام
 * Made by KASSOUANI YT
 * 100% Offline Android & Web Islamic Application
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { PWAInstallPrompt } from './components/PWAInstallPrompt';

import { HomeSection } from './components/HomeSection';
import { AdhkarSection } from './components/AdhkarSection';
import { DuasSection } from './components/DuasSection';
import { NamesOfAllahSection } from './components/NamesOfAllahSection';
import { HadithSection } from './components/HadithSection';
import { TasbihSection } from './components/TasbihSection';
import { PrayerSection } from './components/PrayerSection';
import { QiblaSection } from './components/QiblaSection';
import { CalendarSection } from './components/CalendarSection';
import { FavoritesSection } from './components/FavoritesSection';
import { SearchSection } from './components/SearchSection';
import { SettingsSection } from './components/SettingsSection';
import { AboutSection } from './components/AboutSection';

const MainContent: React.FC = () => {
  const { activeTab } = useApp();

  const renderActiveSection = () => {
    switch (activeTab) {
      case 'home':
        return <HomeSection />;
      case 'adhkar':
        return <AdhkarSection />;
      case 'duas':
        return <DuasSection />;
      case 'names':
        return <NamesOfAllahSection />;
      case 'hadith':
        return <HadithSection />;
      case 'tasbih':
        return <TasbihSection />;
      case 'prayer':
        return <PrayerSection />;
      case 'qibla':
        return <QiblaSection />;
      case 'calendar':
        return <CalendarSection />;
      case 'favorites':
        return <FavoritesSection />;
      case 'search':
        return <SearchSection />;
      case 'settings':
        return <SettingsSection />;
      case 'about':
        return <AboutSection />;
      default:
        return <HomeSection />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors selection:bg-emerald-600 selection:text-white islamic-pattern">
      {/* Top Header */}
      <Header />

      {/* PWA Install Banner & Offline Notice */}
      <PWAInstallPrompt />

      {/* Scrollable Main Screen Container */}
      <main className="flex-1 w-full max-w-4xl mx-auto px-3.5 py-4">
        {renderActiveSection()}
      </main>

      {/* Bottom Floating/Fixed Navigation Bar */}
      <BottomNav />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
