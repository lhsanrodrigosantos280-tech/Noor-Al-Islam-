import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  Moon, 
  Sun, 
  Type, 
  Volume2, 
  VolumeX, 
  Smartphone, 
  Calendar, 
  Clock, 
  RotateCcw, 
  Info, 
  Check,
  ChevronLeft
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CALCULATION_METHODS } from '../data/prayerCalc';

export const SettingsSection: React.FC = () => {
  const {
    isDarkMode,
    setIsDarkMode,
    fontSize,
    setFontSize,
    soundEnabled,
    setSoundEnabled,
    vibrationEnabled,
    setVibrationEnabled,
    hijriAdjustment,
    setHijriAdjustment,
    prayerMethod,
    setPrayerMethod,
    asrMethod,
    setAsrMethod,
    setActiveTab,
  } = useApp();

  const [resetSuccess, setResetSuccess] = useState(false);

  const handleResetDefaults = () => {
    if (confirm('هل أنت متأكد من رغبتك في إعادة ضبط إعدادات التطبيق إلى الوضع الافتراضي؟')) {
      setIsDarkMode(false);
      setFontSize('md');
      setSoundEnabled(true);
      setVibrationEnabled(true);
      setHijriAdjustment(0);
      setPrayerMethod('makkah');
      setAsrMethod('standard');
      setResetSuccess(true);
      setTimeout(() => setResetSuccess(false), 3000);
    }
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-950 text-white rounded-3xl p-5 shadow-xs border border-emerald-700/50">
        <h2 className="text-lg font-bold text-amber-300 flex items-center gap-2">
          <SettingsIcon className="w-5 h-5 text-amber-400" />
          <span>إعدادات التطبيق</span>
        </h2>
        <p className="text-xs text-emerald-200/90 mt-1">
          خصص التطبيق بما يتناسب مع تفضيلاتك ورؤية الهلال في بلدك
        </p>
      </div>

      {resetSuccess && (
        <div className="bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-200 text-xs p-3 rounded-2xl border border-emerald-300 flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600" />
          <span>تمت إعادة ضبط جميع الإعدادات إلى الوضع الافتراضي بنجاح.</span>
        </div>
      )}

      {/* Appearance & Dark Mode */}
      <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Sun className="w-4 h-4 text-amber-500" />
          <span>المظهر والسمة</span>
        </h3>

        <div className="flex items-center justify-between pt-1">
          <div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
              الوضع الليلي (الداكن)
            </span>
            <span className="text-[11px] text-slate-500">مريح للعينين أثناء القراءة ليلاً</span>
          </div>

          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
              isDarkMode ? 'bg-emerald-700' : 'bg-slate-300'
            }`}
          >
            <span
              className={`w-5 h-5 rounded-full bg-white shadow-xs absolute top-0.5 transition-transform ${
                isDarkMode ? 'left-6' : 'left-1'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Font Size Settings */}
      <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Type className="w-4 h-4 text-emerald-600" />
          <span>حجم الخط العربي (للأذكار والأدعية)</span>
        </h3>

        <div className="grid grid-cols-4 gap-2">
          {[
            { id: 'sm', label: 'صغير' },
            { id: 'md', label: 'متوسط' },
            { id: 'lg', label: 'كبير' },
            { id: 'xl', label: 'كبير جداً' },
          ].map((s) => (
            <button
              key={s.id}
              onClick={() => setFontSize(s.id as 'sm' | 'md' | 'lg' | 'xl')}
              className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                fontSize === s.id
                  ? 'bg-emerald-800 text-amber-300 border-emerald-700 shadow-xs'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>

        {/* Live Font Sample */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 text-center">
          <span className="text-[10px] text-slate-400 block mb-1">معاينة الخط:</span>
          <p
            className={`font-amiri text-slate-800 dark:text-slate-200 ${
              fontSize === 'sm'
                ? 'text-base'
                : fontSize === 'md'
                ? 'text-lg'
                : fontSize === 'lg'
                ? 'text-xl'
                : 'text-2xl'
            }`}
          >
            بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ
          </p>
        </div>
      </div>

      {/* Sounds and Haptic Feedback */}
      <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Volume2 className="w-4 h-4 text-emerald-600" />
          <span>الأصوات والاهتزاز</span>
        </h3>

        {/* Sound toggle */}
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
              أصوات المسبحة والنغمات
            </span>
            <span className="text-[11px] text-slate-500">صوت نقر الخرزات ونغمة إتمام الورد</span>
          </div>

          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
              soundEnabled ? 'bg-emerald-700' : 'bg-slate-300'
            }`}
          >
            <span
              className={`w-5 h-5 rounded-full bg-white shadow-xs absolute top-0.5 transition-transform ${
                soundEnabled ? 'left-6' : 'left-1'
              }`}
            />
          </button>
        </div>

        {/* Vibration toggle */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
          <div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
              الاهتزاز اللمسي (Haptic)
            </span>
            <span className="text-[11px] text-slate-500">اهتزاز خفيف عند الضغط في المسبحة وبوصلة القبلة</span>
          </div>

          <button
            onClick={() => setVibrationEnabled(!vibrationEnabled)}
            className={`w-12 h-6.5 rounded-full transition-colors relative cursor-pointer ${
              vibrationEnabled ? 'bg-emerald-700' : 'bg-slate-300'
            }`}
          >
            <span
              className={`w-5 h-5 rounded-full bg-white shadow-xs absolute top-0.5 transition-transform ${
                vibrationEnabled ? 'left-6' : 'left-1'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Hijri Adjustment Setting */}
      <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Calendar className="w-4 h-4 text-emerald-600" />
          <span>تعديل التاريخ الهجري (رؤية الهلال)</span>
        </h3>
        <p className="text-xs text-slate-500">
          إذا كان التاريخ في منطقتك يختلف عن التقويم الحسابي بيوم أو يومين، يمكنك ضبطه هنا:
        </p>

        <div className="flex items-center justify-center gap-2">
          {[-2, -1, 0, 1, 2].map((adj) => (
            <button
              key={adj}
              onClick={() => setHijriAdjustment(adj)}
              className={`px-3 py-1.5 rounded-xl font-mono text-xs font-bold transition-all cursor-pointer ${
                hijriAdjustment === adj
                  ? 'bg-emerald-800 text-amber-300 shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {adj > 0 ? `+${adj}` : adj} يوم
            </button>
          ))}
        </div>
      </div>

      {/* Prayer Times Calculation Method */}
      <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Clock className="w-4 h-4 text-emerald-600" />
          <span>طريقة حساب الصلوات المعتمدة</span>
        </h3>

        <div className="space-y-1.5">
          {Object.values(CALCULATION_METHODS).map((m) => (
            <button
              key={m.id}
              onClick={() => setPrayerMethod(m.id)}
              className={`w-full p-2.5 rounded-xl text-right text-xs font-bold flex items-center justify-between border transition-all ${
                prayerMethod === m.id
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-600 text-emerald-950 dark:text-emerald-300'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              <span>{m.name}</span>
              {prayerMethod === m.id && <Check className="w-4 h-4 text-emerald-600" />}
            </button>
          ))}
        </div>

        {/* Asr method */}
        <div className="pt-2">
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block mb-1.5">
            مذهب صلاة العصر:
          </span>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setAsrMethod('standard')}
              className={`p-2 rounded-xl text-xs font-bold text-center border transition-all ${
                asrMethod === 'standard'
                  ? 'bg-emerald-800 text-amber-300 border-emerald-700'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              الجمهور (شافعي/مالكي/حنبلي)
            </button>
            <button
              onClick={() => setAsrMethod('hanafi')}
              className={`p-2 rounded-xl text-xs font-bold text-center border transition-all ${
                asrMethod === 'hanafi'
                  ? 'bg-emerald-800 text-amber-300 border-emerald-700'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
              }`}
            >
              الحنفي (الظل مثلين)
            </button>
          </div>
        </div>
      </div>

      {/* Navigation to About */}
      <button
        onClick={() => setActiveTab('about')}
        className="w-full bg-white dark:bg-slate-800/90 rounded-3xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between text-right hover:border-emerald-300 transition-all cursor-pointer"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 flex items-center justify-center">
            <Info className="w-5 h-5" />
          </div>
          <div>
            <span className="text-sm font-bold text-slate-900 dark:text-white block">حول التطبيق والمطور</span>
            <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-semibold">
              Made by KASSOUANI YT
            </span>
          </div>
        </div>
        <ChevronLeft className="w-5 h-5 text-slate-400" />
      </button>

      {/* Reset Defaults Button */}
      <button
        onClick={handleResetDefaults}
        className="w-full py-3 rounded-2xl bg-slate-100 dark:bg-slate-800 text-rose-600 dark:text-rose-400 font-bold text-xs flex items-center justify-center gap-1.5 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
      >
        <RotateCcw className="w-4 h-4" />
        <span>إعادة ضبط الإعدادات الافتراضية</span>
      </button>
    </div>
  );
};
