import React, { useState } from 'react';
import { 
  Bookmark, 
  Trash2, 
  Copy, 
  Check, 
  Share2, 
  BookOpen, 
  Sparkles, 
  HeartHandshake, 
  Volume2,
  Search
} from 'lucide-react';
import { useApp, FavoriteItem } from '../context/AppContext';
import { soundEngine } from '../utils/audioTones';

export const FavoritesSection: React.FC = () => {
  const { favorites, toggleFavorite, setActiveTab, fontSize } = useApp();
  const [filterType, setFilterType] = useState<string>('all');
  const [query, setQuery] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredFavorites = favorites.filter((item) => {
    const matchesType = filterType === 'all' || item.type === filterType;
    const q = query.trim().toLowerCase();
    if (!q) return matchesType;
    const matchesSearch =
      item.title.toLowerCase().includes(q) ||
      item.arabic.toLowerCase().includes(q) ||
      (item.source && item.source.toLowerCase().includes(q)) ||
      (item.extra && item.extra.toLowerCase().includes(q));
    return matchesType && matchesSearch;
  });

  const handleCopy = (item: FavoriteItem) => {
    const text = `${item.title}\n\n«${item.arabic}»\n\n${item.source ? `المصدر: ${item.source}\n` : ''}${item.extra ? `البيان: ${item.extra}\n` : ''}تطبيق نور الإسلام`;
    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShare = (item: FavoriteItem) => {
    const text = `${item.title}\n\n«${item.arabic}»\n\n${item.source ? `المصدر: ${item.source}\n` : ''}تطبيق نور الإسلام - Made by KASSOUANI YT`;
    if (navigator.share) {
      navigator.share({ title: item.title, text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      alert('تم نسخ العنصر للمشاركة');
    }
  };

  const handleSpeak = (text: string) => {
    soundEngine.speakArabic(text);
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'dhikr': return 'ذكر';
      case 'dua': return 'دعاء';
      case 'name': return 'اسم من أسماء الله';
      case 'hadith': return 'حديث نبوي';
      default: return 'محفوظة';
    }
  };

  const getFontSizeClass = () => {
    switch (fontSize) {
      case 'sm': return 'text-base';
      case 'md': return 'text-lg';
      case 'lg': return 'text-xl';
      case 'xl': return 'text-2xl';
    }
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-950 text-white rounded-3xl p-5 shadow-xs border border-emerald-700/50 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-amber-300 flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-amber-400 fill-current" />
            <span>قائمة المفضلة</span>
          </h2>
          <p className="text-xs text-emerald-200/90 mt-1">
            جميع الأذكار، الأدعية، وأسماء الله الحسنى التي قمت بحفظها
          </p>
        </div>
        <div className="bg-emerald-950/70 border border-emerald-600/50 rounded-2xl px-3 py-1.5 text-center">
          <span className="text-xl font-mono font-bold text-amber-300">{favorites.length}</span>
          <span className="text-[10px] text-emerald-200 block">عنصراً</span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'all', label: 'الكل' },
          { id: 'dhikr', label: 'الأذكار' },
          { id: 'dua', label: 'الأدعية' },
          { id: 'hadith', label: 'الأحاديث' },
          { id: 'name', label: 'أسماء الله' },
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setFilterType(f.id)}
            className={`px-3.5 py-2 rounded-2xl whitespace-nowrap text-xs font-bold transition-all shrink-0 cursor-pointer ${
              filterType === f.id
                ? 'bg-emerald-800 text-amber-300 shadow-xs'
                : 'bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border border-slate-100 dark:border-slate-800 hover:border-emerald-300'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Search Bar */}
      {favorites.length > 0 && (
        <div className="relative">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث في محفوظاتك..."
            className="w-full bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-2xl py-2.5 pr-10 pl-4 text-xs md:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:border-emerald-600 transition-colors shadow-xs"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
        </div>
      )}

      {/* Favorites List */}
      {favorites.length === 0 ? (
        <div className="text-center py-16 bg-white dark:bg-slate-800/80 rounded-3xl p-6 border border-slate-100 dark:border-slate-800 shadow-xs">
          <div className="w-16 h-16 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center mx-auto mb-3">
            <Bookmark className="w-8 h-8 opacity-60" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
            لا توجد عناصر محفوظة حتى الآن
          </h3>
          <p className="text-xs text-slate-500 max-w-xs mx-auto mb-5 leading-relaxed">
            يمكنك حفظ أي ذكر، دعاء، اسم من أسماء الله الحسنى أو حديث نبوي بالضغط على علامة الإشارة المرجعية لسهولة الرجوع إليه لاحقاً.
          </p>
          <div className="flex justify-center gap-2">
            <button
              onClick={() => setActiveTab('adhkar')}
              className="bg-emerald-800 hover:bg-emerald-700 text-amber-300 text-xs font-bold px-4 py-2.5 rounded-xl transition-colors cursor-pointer"
            >
              تصفح الأذكار
            </button>
            <button
              onClick={() => setActiveTab('duas')}
              className="bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold px-4 py-2.5 rounded-xl transition-colors cursor-pointer"
            >
              تصفح الأدعية
            </button>
          </div>
        </div>
      ) : filteredFavorites.length === 0 ? (
        <div className="text-center py-10 bg-white dark:bg-slate-800/80 rounded-3xl p-6 border border-slate-100 dark:border-slate-800">
          <p className="text-sm text-slate-500">لا توجد عناصر تطابق البحث المحدد</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredFavorites.map((item) => (
            <div
              key={item.id}
              className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs hover:border-emerald-300 transition-all"
            >
              <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100 dark:border-slate-700/60">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold px-2 py-0.5 rounded-full">
                    {getTypeLabel(item.type)}
                  </span>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    {item.title}
                  </h3>
                </div>

                <div className="flex items-center gap-1.5">
                  {/* Speak */}
                  <button
                    onClick={() => handleSpeak(item.arabic)}
                    title="استماع"
                    className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-700 dark:hover:text-emerald-300 hover:bg-slate-100 dark:hover:bg-slate-700"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>

                  {/* Copy */}
                  <button
                    onClick={() => handleCopy(item)}
                    title="نسخ"
                    className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-700 dark:hover:text-emerald-300 hover:bg-slate-100 dark:hover:bg-slate-700"
                  >
                    {copiedId === item.id ? (
                      <Check className="w-4 h-4 text-emerald-600 font-bold" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>

                  {/* Share */}
                  <button
                    onClick={() => handleShare(item)}
                    title="مشاركة"
                    className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-700 dark:hover:text-emerald-300 hover:bg-slate-100 dark:hover:bg-slate-700"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>

                  {/* Remove */}
                  <button
                    onClick={() => toggleFavorite(item)}
                    title="حذف من المفضلة"
                    className="p-1.5 rounded-lg text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Arabic Text */}
              <p className={`font-amiri leading-loose text-slate-900 dark:text-slate-100 text-justify mb-3 ${getFontSizeClass()}`}>
                «{item.arabic}»
              </p>

              {/* Extra / Virtue */}
              {item.extra && (
                <div className="bg-slate-50 dark:bg-slate-700/40 rounded-xl p-2.5 text-xs text-slate-600 dark:text-slate-300 mb-2">
                  <p className="leading-relaxed">{item.extra}</p>
                </div>
              )}

              {/* Source footer */}
              {item.source && (
                <div className="text-xs text-slate-400 pt-1 border-t border-slate-100 dark:border-slate-700/50">
                  {item.source}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
