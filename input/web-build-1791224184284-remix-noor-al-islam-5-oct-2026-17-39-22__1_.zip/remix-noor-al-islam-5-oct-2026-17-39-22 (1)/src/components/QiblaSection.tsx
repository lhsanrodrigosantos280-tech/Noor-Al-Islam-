import React, { useState, useEffect, useRef } from 'react';
import { 
  Compass, 
  MapPin, 
  Navigation, 
  RotateCw, 
  AlertCircle, 
  CheckCircle2,
  Sparkles,
  Info
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { calculateQibla, getCompassDirectionArabic } from '../data/qiblaCalc';
import { soundEngine } from '../utils/audioTones';

export const QiblaSection: React.FC = () => {
  const { userLocation, requestGpsLocation, vibrationEnabled } = useApp();

  const [compassHeading, setCompassHeading] = useState<number>(0);
  const [hasCompassSensor, setHasCompassSensor] = useState<boolean | null>(null);
  const [manualHeading, setManualHeading] = useState<number>(0);
  const [permissionState, setPermissionState] = useState<'prompt' | 'granted' | 'denied'>('prompt');
  const [isLocating, setIsLocating] = useState(false);
  const lastVibrateRef = useRef<number>(0);

  const qiblaInfo = calculateQibla(userLocation.lat, userLocation.lng);
  const effectiveHeading = hasCompassSensor ? compassHeading : manualHeading;

  // Difference between current heading and Qibla bearing
  // Needle points in direction of (qiblaBearing - heading)
  const relativeAngle = (qiblaInfo.bearing - effectiveHeading + 360) % 360;
  const isAligned = Math.abs(relativeAngle) <= 6 || Math.abs(relativeAngle - 360) <= 6;

  // Trigger vibration when aligned (throttled)
  useEffect(() => {
    if (isAligned && vibrationEnabled) {
      const now = Date.now();
      if (now - lastVibrateRef.current > 2500) {
        soundEngine.vibrate(60);
        lastVibrateRef.current = now;
      }
    }
  }, [isAligned, vibrationEnabled]);

  // Request orientation permissions (especially iOS 13+)
  const requestOrientationPermission = async () => {
    if (
      typeof window !== 'undefined' &&
      typeof (DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> }).requestPermission === 'function'
    ) {
      try {
        const response = await (DeviceOrientationEvent as unknown as { requestPermission: () => Promise<string> }).requestPermission();
        if (response === 'granted') {
          setPermissionState('granted');
          window.addEventListener('deviceorientation', handleOrientation);
        } else {
          setPermissionState('denied');
        }
      } catch {
        setPermissionState('denied');
      }
    } else {
      window.addEventListener('deviceorientation', handleOrientation);
      setPermissionState('granted');
    }
  };

  const handleOrientation = (e: DeviceOrientationEvent) => {
    let heading = 0;
    const webkitEvent = e as unknown as { webkitCompassHeading?: number };

    if (webkitEvent.webkitCompassHeading !== undefined) {
      // iOS
      heading = webkitEvent.webkitCompassHeading;
      setHasCompassSensor(true);
    } else if (e.alpha !== null) {
      // Android / standard: alpha is counter-clockwise rotation around Z
      heading = (360 - e.alpha) % 360;
      setHasCompassSensor(true);
    } else {
      setHasCompassSensor(false);
    }

    setCompassHeading(Math.round(heading));
  };

  useEffect(() => {
    window.addEventListener('deviceorientation', handleOrientation);
    return () => {
      window.removeEventListener('deviceorientation', handleOrientation);
    };
  }, []);

  const handleLocate = async () => {
    setIsLocating(true);
    await requestGpsLocation();
    setIsLocating(false);
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in flex flex-col items-center">
      {/* Top Info Banner */}
      <div className="w-full bg-white dark:bg-slate-800/90 rounded-3xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 flex items-center justify-center">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">بوصلة القبلة المشرفة</h2>
            <div className="flex items-center gap-1 text-[11px] text-slate-500">
              <MapPin className="w-3 h-3 text-emerald-600" />
              <span>{userLocation.name}</span>
            </div>
          </div>
        </div>

        <button
          onClick={handleLocate}
          disabled={isLocating}
          className="flex items-center gap-1 text-xs bg-emerald-800 hover:bg-emerald-700 text-amber-300 font-bold px-3 py-1.5 rounded-xl transition-all shadow-xs cursor-pointer disabled:opacity-50"
        >
          <Navigation className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
          <span>تحديث GPS</span>
        </button>
      </div>

      {/* Alignment Status Banner */}
      <div
        className={`w-full p-4 rounded-3xl text-center transition-all duration-300 border ${
          isAligned
            ? 'bg-emerald-800 text-white border-amber-400 shadow-lg scale-102 ring-4 ring-emerald-500/20'
            : 'bg-white dark:bg-slate-800/90 text-slate-800 dark:text-slate-100 border-slate-100 dark:border-slate-800 shadow-xs'
        }`}
      >
        <div className="flex items-center justify-center gap-2 mb-1">
          {isAligned ? (
            <>
              <CheckCircle2 className="w-5 h-5 text-amber-300 animate-bounce" />
              <span className="text-base md:text-lg font-black text-amber-300">
                أنت الآن باتجاه القبلة الشريفة!
              </span>
            </>
          ) : (
            <>
              <RotateCw className="w-4 h-4 text-emerald-600 animate-spin" />
              <span className="text-sm font-bold">
                أدر الهاتف حتى يتطابق المؤشر الأخضر مع الكعبة
              </span>
            </>
          )}
        </div>
        <p className="text-xs opacity-90">
          زاوية القبلة من موقعك:{' '}
          <strong className="font-mono text-sm">{qiblaInfo.bearing}°</strong> ({getCompassDirectionArabic(qiblaInfo.bearing)}) • المسافة: {qiblaInfo.distanceKm.toLocaleString('ar-EG')} كم
        </p>
      </div>

      {/* Main Compass Dial */}
      <div className="relative my-4 flex items-center justify-center select-none">
        {/* Outer Circular Rim */}
        <div className="w-72 h-72 md:w-80 md:h-80 rounded-full bg-gradient-to-b from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-900 border-8 border-slate-300 dark:border-slate-700 shadow-2xl relative flex items-center justify-center">
          {/* Compass Dial Face with Smooth Rotation */}
          <div
            className="w-full h-full rounded-full relative flex items-center justify-center transition-transform duration-300 ease-out"
            style={{ transform: `rotate(${-effectiveHeading}deg)` }}
          >
            {/* Cardinal Direction Points */}
            <span className="absolute top-2 font-black text-rose-600 text-sm">شمال (N)</span>
            <span className="absolute bottom-2 font-bold text-slate-500 text-xs">جنوب (S)</span>
            <span className="absolute right-3 font-bold text-slate-500 text-xs">شرق (E)</span>
            <span className="absolute left-3 font-bold text-slate-500 text-xs">غرب (W)</span>

            {/* Degree Markings around rim */}
            {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => (
              <div
                key={deg}
                className="absolute w-1 h-3 bg-slate-400/60 dark:bg-slate-500/60 origin-bottom"
                style={{
                  top: '6px',
                  transformOrigin: '50% 136px',
                  transform: `rotate(${deg}deg)`,
                }}
              />
            ))}

            {/* Qibla Direction Indicator Needle (Points directly to Kaaba angle) */}
            <div
              className="absolute inset-0 flex items-center justify-center pointer-events-none"
              style={{ transform: `rotate(${qiblaInfo.bearing}deg)` }}
            >
              {/* Green Kaaba Arrow Pointer */}
              <div className="absolute -top-1 flex flex-col items-center">
                {/* Kaaba Emblem Box */}
                <div className="w-8 h-8 rounded-lg bg-slate-950 border-2 border-amber-400 shadow-md flex items-center justify-center text-amber-300">
                  <div className="w-4 h-4 border-t-2 border-amber-400 flex items-center justify-center">
                    <span className="text-[8px] font-bold">🕋</span>
                  </div>
                </div>
                <div className="w-0.5 h-16 bg-gradient-to-b from-amber-400 to-emerald-500 mt-0.5" />
              </div>
            </div>

            {/* North Red Pointer */}
            <div className="absolute top-7 w-2 h-14 bg-gradient-to-t from-slate-400 to-rose-600 rounded-full" />
          </div>

          {/* Central Compass Pivot Hub */}
          <div className="absolute w-14 h-14 rounded-full bg-slate-900 text-white border-2 border-amber-400 flex flex-col items-center justify-center shadow-lg z-10">
            <span className="text-xs font-mono font-bold text-amber-300">{effectiveHeading}°</span>
          </div>
        </div>
      </div>

      {/* Manual Compass Rotation Slider if no hardware compass */}
      {hasCompassSensor === false && (
        <div className="w-full bg-white dark:bg-slate-800/90 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs">
          <div className="flex items-center gap-1.5 text-xs text-amber-600 dark:text-amber-400 font-bold mb-2">
            <Info className="w-4 h-4" />
            <span>الجهاز لا يحتوي على حساس بوصلة رقمية (مستشعر مغناطيسي):</span>
          </div>
          <p className="text-xs text-slate-500 mb-3">
            يمكنك تدوير البوصلة يدوياً بمحاذاة اتجاه الشمس أو الشمال في منطقتك:
          </p>
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono">{manualHeading}°</span>
            <input
              type="range"
              min="0"
              max="359"
              value={manualHeading}
              onChange={(e) => setManualHeading(parseInt(e.target.value, 10))}
              className="flex-1 accent-emerald-600 cursor-pointer"
            />
          </div>
        </div>
      )}

      {/* Permission Button for iOS Safari */}
      {typeof window !== 'undefined' &&
        typeof (DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> }).requestPermission === 'function' &&
        permissionState === 'prompt' && (
          <button
            onClick={requestOrientationPermission}
            className="w-full bg-emerald-800 text-white font-bold py-2.5 rounded-2xl text-xs shadow-sm hover:bg-emerald-700 transition-colors"
          >
            تفعيل حساس البوصلة في المتصفح
          </button>
        )}

      {/* Calibration Tips */}
      <div className="w-full bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-3.5 border border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400">
        <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-1 flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          <span>نصائح لدقة البوصلة:</span>
        </h4>
        <ul className="list-disc list-inside space-y-1 pr-1 text-[11px] leading-relaxed">
          <li>ضع الهاتف بشكل أفقي تماماً ومستوٍ في راحة يدك.</li>
          <li>ابتعد عن الأجهزة الإلكترونية والمعادن الكبيرة وأغلفة الهاتف المغناطيسية.</li>
          <li>قم بتحريك الهاتف على شكل رقم (8) في الهواء لمعايرة المستشعر.</li>
        </ul>
      </div>
    </div>
  );
};
