import React, { useEffect, useState } from 'react';
import { Download, CheckCircle, WifiOff } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const PWAInstallPrompt: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [showIOSModal, setShowIOSModal] = useState(false);
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  useEffect(() => {
    // Check if already standalone
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(isStandalone);

    // Detect iOS
    const ua = window.navigator.userAgent.toLowerCase();
    setIsIOS(/iphone|ipad|ipod/.test(ua));

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleAppInstalled);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    } else if (isIOS) {
      setShowIOSModal(true);
    }
  };

  return (
    <>
      {/* Offline Mode notification badge */}
      {!isOnline && (
        <div className="bg-amber-600/90 text-white text-xs px-3 py-1.5 flex items-center justify-center gap-2 shadow-sm text-center">
          <WifiOff className="w-3.5 h-3.5" />
          <span>أنت تعمل في وضع عدم الاتصال (أوفلاين) - جميع المحتويات الإسلامية متوفرة بالكامل</span>
        </div>
      )}

      {/* In-app install banner when available */}
      {!isInstalled && (deferredPrompt || isIOS) && (
        <div className="bg-emerald-900/90 border-b border-emerald-700/50 text-white px-4 py-2 flex items-center justify-between gap-3 text-xs md:text-sm">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-emerald-700 flex items-center justify-center">
              <Download className="w-4 h-4 text-emerald-200" />
            </div>
            <div>
              <p className="font-bold">تثبيت تطبيق نور الإسلام</p>
              <p className="text-emerald-300 text-[11px]">يعمل 100% بدون إنترنت على جهازك</p>
            </div>
          </div>
          <button
            onClick={handleInstallClick}
            className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-3 py-1.5 rounded-lg text-xs transition-colors flex items-center gap-1 shadow-sm active:scale-95"
          >
            <span>تثبيت الآن</span>
          </button>
        </div>
      )}

      {/* iOS Safari Guide Modal */}
      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-sm w-full p-5 text-right shadow-2xl border border-emerald-800/30">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-600" />
              تثبيت على أجهزة iPhone / iPad
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-300 mb-4 leading-relaxed">
              لتثبيت التطبيق وتشغيله بدون إنترنت:
              <br />
              1. اضغط على زر <strong>المشاركة (Share)</strong> أسفل المتصفح.
              <br />
              2. مرر للأسفل واختر <strong>إضافة إلى الشاشة الرئيسية (Add to Home Screen)</strong>.
            </p>
            <button
              onClick={() => setShowIOSModal(false)}
              className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-medium py-2 rounded-xl text-sm transition-colors"
            >
              فهمت، شكراً
            </button>
          </div>
        </div>
      )}
    </>
  );
};
