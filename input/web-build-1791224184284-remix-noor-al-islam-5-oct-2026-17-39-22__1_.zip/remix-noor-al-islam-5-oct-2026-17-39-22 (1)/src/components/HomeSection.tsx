import React, { useEffect, useState } from 'react';
import { 
  BookOpen, 
  Sparkles, 
  HeartHandshake, 
  CircleDot, 
  Clock, 
  Compass, 
  Calendar, 
  Bookmark, 
  ChevronLeft, 
  MapPin,
  Flame,
  Volume2,
  VolumeX,
  Share2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { calculatePrayerTimes } from '../data/prayerCalc';
import { getHijriDate } from '../data/hijriDate';
import { HADITHS_DATA } from '../data/hadithData';
import { soundEngine } from '../utils/audioTones';

export const HomeSection: React.FC = () => {
  const {
    setActiveTab,
    setTargetCategory,
    userLocation,
    prayerMethod,
    asrMethod,
    hijriAdjustment,
    tasbihCount,
    tasbihTarget,
    tasbihTotal,
    tasbihDhikr,
    incrementTasbih,
    soundEnabled,
    setSoundEnabled,
    vibrationEnabled,
  } = useApp();

  const [currentTime, setCurrentTime] = useState(new Date());

  // Update clock every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const hijri = getHijriDate(currentTime, hijriAdjustment);
  const prayerResult = calculatePrayerTimes(
    currentTime,
    userLocation.lat,
    userLocation.lng,
    userLocation.timezoneOffset,
    prayerMethod,
    asrMethod
  );

  // Daily Hadith (pick stable hadith based on day of month)
  const hadithIndex = currentTime.getDate() % HADITHS_DATA.length;
  const dailyHadith = HADITHS_DATA[hadithIndex];

  const handleTasbihTap = () => {
    if (soundEnabled) soundEngine.playBeadClick();
    if (vibrationEnabled) soundEngine.vibrate(30);

    const nextCount = tasbihCount + 1;
    if (tasbihTarget > 0 && nextCount >= tasbihTarget) {
      if (soundEnabled) soundEngine.playCompletionChime();
      if (vibrationEnabled) soundEngine.vibratePattern();
    }
    incrementTasbih();
  };

  const handleShareHadith = () => {
    if (navigator.share) {
      navigator.share({
        title: dailyHadith.title,
        text: `${dailyHadith.title}\n\n${dailyHadith.arabic}\n\nالراوي: ${dailyHadith.narrator}\nالمصدر: ${dailyHadith.source}\n\nتطبيق نور الإسلام - Made by KASSOUANI YT`,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(`${dailyHadith.arabic}\n\nالمصدر: ${dailyHadith.source}`);
      alert('تم نسخ الحديث الشريف إلى الحافظة');
    }
  };

  const prayersList = [
    { key: 'fajr', name: 'الفجر', time: prayerResult.fajr },
    { key: 'sunrise', name: 'الشروق', time: prayerResult.sunrise },
    { key: 'dhuhr', name: 'الظهر', time: prayerResult.dhuhr },
    { key: 'asr', name: 'العصر', time: prayerResult.asr },
    { key: 'maghrib', name: 'المغرب', time: prayerResult.maghrib },
    { key: 'isha', name: 'العشاء', time: prayerResult.isha },
  ];

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* Hero Card: Islamic Greeting & Next Prayer Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-950 text-white p-5 shadow-lg border border-emerald-700/40">
        {/* Subtle geometric background motif */}
        <div className="absolute -left-10 -bottom-10 w-44 h-44 rounded-full bg-emerald-700/20 blur-2xl pointer-events-none" />
        <div className="absolute -right-10 -top-10 w-44 h-44 rounded-full bg-amber-500/10 blur-2xl pointer-events-none" />

        <div className="relative z-10 flex items-start justify-between">
          <div>
            <span className="text-xs text-emerald-200/90 font-medium tracking-wide">
              {hijri.gregorianFormatted}
            </span>
            <h2 className="text-xl md:text-2xl font-black text-amber-300 mt-0.5">
              {hijri.formatted}
            </h2>
          </div>
          <button
            onClick={() => setActiveTab('prayer')}
            className="flex items-center gap-1 text-xs bg-emerald-800/80 hover:bg-emerald-700/80 px-2.5 py-1.5 rounded-xl border border-emerald-600/40 text-emerald-100 transition-colors"
          >
            <MapPin className="w-3.5 h-3.5 text-amber-400" />
            <span className="max-w-[100px] truncate">{userLocation.name}</span>
          </button>
        </div>

        {/* Next Prayer Countdown Card */}
        <div className="mt-4 pt-3.5 border-t border-emerald-700/40 flex items-center justify-between">
          <div>
            <p className="text-xs text-emerald-200/90">الصلاة القادمة</p>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="text-2xl md:text-3xl font-extrabold text-white">
                صلاة {prayerResult.nextPrayer.name}
              </span>
              <span className="text-sm font-semibold text-amber-300">
                {prayerResult.nextPrayer.timeStr}
              </span>
            </div>
          </div>

          <div className="text-left bg-emerald-950/60 border border-emerald-600/40 rounded-2xl px-3.5 py-2">
            <span className="text-[10px] text-emerald-300 block text-center">متبقي للأذان</span>
            <span className="text-lg md:text-xl font-mono font-bold text-amber-400">
              {prayerResult.nextPrayer.timeRemaining}
            </span>
          </div>
        </div>

        {/* Horizontal Mini Prayer Times Row */}
        <div className="mt-4 pt-3 border-t border-emerald-700/30 grid grid-cols-6 gap-1 text-center">
          {prayersList.map((p) => {
            const isNext = prayerResult.nextPrayer.key === p.key;
            return (
              <div
                key={p.key}
                className={`py-1.5 px-1 rounded-xl transition-all ${
                  isNext
                    ? 'bg-amber-400 text-emerald-950 font-bold shadow-sm scale-105'
                    : 'bg-emerald-800/40 text-emerald-100'
                }`}
              >
                <span className="text-[10px] block opacity-90">{p.name}</span>
                <span className="text-xs font-mono font-bold">{p.time}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Grid Navigation (8 Quick Access Features) */}
      <div>
        <div className="flex items-center justify-between mb-2.5 px-1">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">الخدمات الإسلامية</h3>
          <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">100% بدون إنترنت</span>
        </div>

        <div className="grid grid-cols-4 gap-2 md:gap-3">
          {/* Adhkar */}
          <button
            onClick={() => setActiveTab('adhkar')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800 shadow-xs hover:border-emerald-500/50 hover:shadow-sm transition-all group active:scale-95"
          >
            <div className="w-11 h-11 rounded-2xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
              <BookOpen className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-100">الأذكار</span>
            <span className="text-[10px] text-slate-400 dark:text-slate-400">حصن المسلم</span>
          </button>

          {/* Duas */}
          <button
            onClick={() => setActiveTab('duas')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800 shadow-xs hover:border-emerald-500/50 hover:shadow-sm transition-all group active:scale-95"
          >
            <div className="w-11 h-11 rounded-2xl bg-teal-100 dark:bg-teal-900/60 text-teal-700 dark:text-teal-300 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
              <HeartHandshake className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-100">الأدعية</span>
            <span className="text-[10px] text-slate-400 dark:text-slate-400">قرآنية وسنة</span>
          </button>

          {/* 99 Names */}
          <button
            onClick={() => setActiveTab('names')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800 shadow-xs hover:border-emerald-500/50 hover:shadow-sm transition-all group active:scale-95"
          >
            <div className="w-11 h-11 rounded-2xl bg-amber-100 dark:bg-amber-900/50 text-amber-700 dark:text-amber-300 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
              <Sparkles className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-100">أسماء الله</span>
            <span className="text-[10px] text-slate-400 dark:text-slate-400">99 اسماً</span>
          </button>

          {/* Authentic Hadith */}
          <button
            onClick={() => setActiveTab('hadith')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800 shadow-xs hover:border-emerald-500/50 hover:shadow-sm transition-all group active:scale-95"
          >
            <div className="w-11 h-11 rounded-2xl bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
              <BookOpen className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-100">الأحاديث</span>
            <span className="text-[10px] text-slate-400 dark:text-slate-400">صحيحة</span>
          </button>

          {/* Digital Tasbih */}
          <button
            onClick={() => setActiveTab('tasbih')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800 shadow-xs hover:border-emerald-500/50 hover:shadow-sm transition-all group active:scale-95"
          >
            <div className="w-11 h-11 rounded-2xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
              <CircleDot className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-100">المسبحة</span>
            <span className="text-[10px] text-slate-400 dark:text-slate-400">عداد الذكر</span>
          </button>

          {/* Qibla Direction */}
          <button
            onClick={() => setActiveTab('qibla')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800 shadow-xs hover:border-emerald-500/50 hover:shadow-sm transition-all group active:scale-95"
          >
            <div className="w-11 h-11 rounded-2xl bg-yellow-100 dark:bg-yellow-900/50 text-yellow-700 dark:text-yellow-300 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
              <Compass className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-100">القبلة</span>
            <span className="text-[10px] text-slate-400 dark:text-slate-400">بوصلة دقيقة</span>
          </button>

          {/* Hijri Calendar */}
          <button
            onClick={() => setActiveTab('calendar')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800 shadow-xs hover:border-emerald-500/50 hover:shadow-sm transition-all group active:scale-95"
          >
            <div className="w-11 h-11 rounded-2xl bg-purple-100 dark:bg-purple-900/50 text-purple-700 dark:text-purple-300 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
              <Calendar className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-100">التقويم</span>
            <span className="text-[10px] text-slate-400 dark:text-slate-400">المناسبات</span>
          </button>

          {/* Favorites */}
          <button
            onClick={() => setActiveTab('favorites')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800 shadow-xs hover:border-emerald-500/50 hover:shadow-sm transition-all group active:scale-95"
          >
            <div className="w-11 h-11 rounded-2xl bg-rose-100 dark:bg-rose-900/50 text-rose-700 dark:text-rose-300 flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
              <Bookmark className="w-6 h-6" />
            </div>
            <span className="text-xs font-bold text-slate-800 dark:text-slate-100">المفضلة</span>
            <span className="text-[10px] text-slate-400 dark:text-slate-400">محفوظاتك</span>
          </button>
        </div>
      </div>

      {/* Quick Interactive Tasbih Card on Home */}
      <div className="bg-gradient-to-r from-emerald-800 to-teal-900 rounded-3xl p-4 text-white shadow-md border border-emerald-700/50 flex items-center justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[11px] font-semibold text-emerald-300">مسبحة سريعة</span>
            <span className="text-[10px] bg-emerald-950/60 px-2 py-0.5 rounded-full text-amber-300">
              المجموع: {tasbihTotal}
            </span>
          </div>
          <p className="text-base font-bold text-white font-amiri mb-2">
            {tasbihDhikr}
          </p>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('tasbih')}
              className="text-xs text-amber-300 hover:text-amber-200 underline font-medium flex items-center gap-0.5"
            >
              <span>فتح المسبحة الكاملة</span>
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              className="text-emerald-200 hover:text-white p-1 rounded-lg"
              title={soundEnabled ? 'كتم الصوت' : 'تشغيل الصوت'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 opacity-70" />}
            </button>
          </div>
        </div>

        {/* Big Tap Button */}
        <button
          onClick={handleTasbihTap}
          className="w-18 h-18 rounded-2xl bg-amber-400 hover:bg-amber-300 active:scale-90 text-emerald-950 font-black shadow-lg flex flex-col items-center justify-center transition-all cursor-pointer select-none"
        >
          <span className="text-xl font-mono leading-none">{tasbihCount}</span>
          <span className="text-[10px] font-medium opacity-80">
            {tasbihTarget > 0 ? `من ${tasbihTarget}` : 'سبّح'}
          </span>
        </button>
      </div>

      {/* Daily Authentic Hadith Card */}
      <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs">
        <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100 dark:border-slate-700/50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 flex items-center justify-center">
              <Flame className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">حديث اليوم المبارك</h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">عن {dailyHadith.narrator}</p>
            </div>
          </div>
          <button
            onClick={handleShareHadith}
            title="مشاركة الحديث"
            className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-700 dark:hover:text-emerald-400 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>

        <p className="text-base md:text-lg font-amiri leading-relaxed text-slate-800 dark:text-slate-100 text-justify mb-3">
          {dailyHadith.arabic}
        </p>

        <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-700/50">
          <span className="font-semibold text-emerald-700 dark:text-emerald-400">{dailyHadith.source}</span>
          <button
            onClick={() => setActiveTab('hadith')}
            className="text-amber-600 dark:text-amber-400 font-bold flex items-center gap-0.5 hover:underline"
          >
            <span>المزيد من الأحاديث</span>
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Quick Morning & Evening Adhkar Shortcuts */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => {
            setTargetCategory('morning');
            setActiveTab('adhkar');
          }}
          className="p-4 rounded-2xl bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/40 dark:to-orange-950/30 border border-amber-200/60 dark:border-amber-900/40 text-right transition-all hover:border-amber-400 group active:scale-95"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xl">🌅</span>
            <ChevronLeft className="w-4 h-4 text-amber-700 dark:text-amber-300 group-hover:-translate-x-1 transition-transform" />
          </div>
          <h4 className="font-bold text-sm text-slate-900 dark:text-white">أذكار الصباح</h4>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">ابدأ يومك بنور الذكر والتحصين</p>
        </button>

        <button
          onClick={() => {
            setTargetCategory('evening');
            setActiveTab('adhkar');
          }}
          className="p-4 rounded-2xl bg-gradient-to-br from-indigo-50 to-emerald-50 dark:from-indigo-950/40 dark:to-emerald-950/30 border border-indigo-200/60 dark:border-indigo-900/40 text-right transition-all hover:border-indigo-400 group active:scale-95"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xl">🌙</span>
            <ChevronLeft className="w-4 h-4 text-indigo-700 dark:text-indigo-300 group-hover:-translate-x-1 transition-transform" />
          </div>
          <h4 className="font-bold text-sm text-slate-900 dark:text-white">أذكار المساء</h4>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">حصنك وسكينتك عند الغروب</p>
        </button>
      </div>

      {/* Developer credit note */}
      <div className="text-center py-2 text-xs text-slate-400 dark:text-slate-500 font-medium">
        نور الإسلام • Made by <span className="font-bold text-emerald-700 dark:text-emerald-400">KASSOUANI YT</span>
      </div>
    </div>
  );
};
