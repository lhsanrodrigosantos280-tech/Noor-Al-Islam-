import React, { useState } from 'react';
import { 
  HeartHandshake, 
  Bookmark, 
  Copy, 
  Check, 
  Share2, 
  Search, 
  Sparkles,
  Volume2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DUAS_CATEGORIES, DuaItem } from '../data/duasData';
import { soundEngine } from '../utils/audioTones';

export const DuasSection: React.FC = () => {
  const { toggleFavorite, isFavorite, fontSize } = useApp();
  const [selectedCatId, setSelectedCatId] = useState<string>('quranic');
  const [duaQuery, setDuaQuery] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const selectedCategory = DUAS_CATEGORIES.find(c => c.id === selectedCatId) || DUAS_CATEGORIES[0];

  // Filter items by category and optional search query
  let itemsToDisplay: (DuaItem & { categoryName?: string })[] = [];
  if (duaQuery.trim()) {
    const q = duaQuery.trim().toLowerCase();
    DUAS_CATEGORIES.forEach(cat => {
      cat.items.forEach(it => {
        if (
          it.title.toLowerCase().includes(q) ||
          it.arabic.toLowerCase().includes(q) ||
          (it.virtue && it.virtue.toLowerCase().includes(q))
        ) {
          itemsToDisplay.push({ ...it, categoryName: cat.name });
        }
      });
    });
  } else {
    itemsToDisplay = selectedCategory.items;
  }

  const handleCopy = (item: DuaItem) => {
    const text = `${item.title}\n\n«${item.arabic}»\n\nالمصدر: ${item.source}${item.virtue ? `\nالفضل: ${item.virtue}` : ''}\n\nتطبيق نور الإسلام`;
    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShare = (item: DuaItem) => {
    const text = `${item.title}\n\n«${item.arabic}»\n\nالمصدر: ${item.source}\n\nتطبيق نور الإسلام - Made by KASSOUANI YT`;
    if (navigator.share) {
      navigator.share({ title: item.title, text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      alert('تم نسخ الدعاء للمشاركة');
    }
  };

  const handleSpeak = (text: string) => {
    soundEngine.speakArabic(text);
  };

  const getFontSizeClass = () => {
    switch (fontSize) {
      case 'sm': return 'text-base';
      case 'md': return 'text-lg';
      case 'lg': return 'text-xl';
      case 'xl': return 'text-2xl';
    }
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* Category selector */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        {DUAS_CATEGORIES.map(cat => {
          const isActive = selectedCatId === cat.id && !duaQuery;
          return (
            <button
              key={cat.id}
              onClick={() => {
                setSelectedCatId(cat.id);
                setDuaQuery('');
              }}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl whitespace-nowrap text-xs font-bold transition-all shrink-0 cursor-pointer ${
                isActive
                  ? 'bg-emerald-800 text-amber-300 shadow-sm'
                  : 'bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border border-slate-100 dark:border-slate-800 hover:border-emerald-300'
              }`}
            >
              <HeartHandshake className="w-3.5 h-3.5" />
              <span>{cat.name}</span>
            </button>
          );
        })}
      </div>

      {/* Search Bar for Duas */}
      <div className="relative">
        <input
          type="text"
          value={duaQuery}
          onChange={(e) => setDuaQuery(e.target.value)}
          placeholder="ابحث في الأدعية القرآنية والنبوية..."
          className="w-full bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-2xl py-2.5 pr-10 pl-4 text-xs md:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:border-emerald-600 transition-colors shadow-xs"
        />
        <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
        {duaQuery && (
          <button
            onClick={() => setDuaQuery('')}
            className="absolute left-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
          >
            مسح
          </button>
        )}
      </div>

      {/* Category Description Banner */}
      {!duaQuery && (
        <div className="bg-gradient-to-r from-emerald-900 to-teal-950 text-white rounded-3xl p-4 shadow-xs border border-emerald-800/50">
          <h2 className="text-base font-bold text-amber-300 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>{selectedCategory.name}</span>
          </h2>
          <p className="text-xs text-emerald-200/90 mt-1">
            {selectedCategory.description}
          </p>
        </div>
      )}

      {/* Duas List */}
      <div className="space-y-3">
        {itemsToDisplay.length === 0 ? (
          <div className="text-center py-10 bg-white dark:bg-slate-800/80 rounded-3xl p-6 border border-slate-100 dark:border-slate-800">
            <p className="text-sm text-slate-500">لم يتم العثور على أدعية مطابقة لبحثك</p>
          </div>
        ) : (
          itemsToDisplay.map((item) => {
            const favorite = isFavorite(item.id);
            return (
              <div
                key={item.id}
                className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs hover:border-emerald-300 transition-all"
              >
                {/* Header */}
                <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100 dark:border-slate-700/60">
                  <h3 className="font-bold text-sm md:text-base text-slate-900 dark:text-white">
                    {item.title}
                  </h3>

                  <div className="flex items-center gap-1.5">
                    {/* Speak button */}
                    <button
                      onClick={() => handleSpeak(item.arabic)}
                      title="الاستماع للدعاء"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-700 dark:hover:text-emerald-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>

                    {/* Copy */}
                    <button
                      onClick={() => handleCopy(item)}
                      title="نسخ الدعاء"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-700 dark:hover:text-emerald-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-4 h-4 text-emerald-600 font-bold" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>

                    {/* Share */}
                    <button
                      onClick={() => handleShare(item)}
                      title="مشاركة"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-700 dark:hover:text-emerald-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>

                    {/* Favorite */}
                    <button
                      onClick={() =>
                        toggleFavorite({
                          id: item.id,
                          type: 'dua',
                          title: item.title,
                          arabic: item.arabic,
                          source: item.source,
                          extra: item.virtue,
                        })
                      }
                      title="إضافة للمفضلة"
                      className={`p-1.5 rounded-lg transition-colors ${
                        favorite
                          ? 'text-amber-500'
                          : 'text-slate-400 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-700'
                      }`}
                    >
                      <Bookmark className={`w-4 h-4 ${favorite ? 'fill-current' : ''}`} />
                    </button>
                  </div>
                </div>

                {/* Arabic Body */}
                <p className={`font-amiri leading-loose text-slate-900 dark:text-slate-100 text-justify mb-3 ${getFontSizeClass()}`}>
                  «{item.arabic}»
                </p>

                {/* Virtue or Merit */}
                {item.virtue && (
                  <div className="bg-emerald-50/70 dark:bg-emerald-950/30 rounded-2xl p-3 text-xs text-emerald-900 dark:text-emerald-200 border border-emerald-100 dark:border-emerald-900/40 mb-3">
                    <span className="font-bold text-emerald-800 dark:text-emerald-300 block mb-0.5">فضل الدعاء:</span>
                    <p className="leading-relaxed">{item.virtue}</p>
                  </div>
                )}

                {/* Source footer */}
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-700/50">
                  <span className="font-medium text-emerald-700 dark:text-emerald-400">
                    {item.source}
                  </span>
                  {item.categoryName && (
                    <span className="text-[11px] text-slate-400">
                      {item.categoryName}
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
