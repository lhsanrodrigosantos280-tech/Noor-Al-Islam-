import React, { useState } from 'react';
import { Home, BookOpen, CircleDot, Clock, Grid, Sparkles, HeartHandshake, Compass, Calendar, Info, X } from 'lucide-react';
import { useApp, TabType } from '../context/AppContext';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab } = useApp();
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  const mainNavItems = [
    { id: 'home' as TabType, label: 'الرئيسية', icon: Home },
    { id: 'adhkar' as TabType, label: 'الأذكار', icon: BookOpen },
    { id: 'tasbih' as TabType, label: 'المسبحة', icon: CircleDot },
    { id: 'prayer' as TabType, label: 'مواقيت الصلاة', icon: Clock },
  ];

  const moreNavItems = [
    { id: 'duas' as TabType, label: 'الأدعية المأثورة', icon: HeartHandshake, desc: 'أدعية قرآنية ونبوية جامعة' },
    { id: 'names' as TabType, label: 'أسماء الله الحسنى', icon: Sparkles, desc: '99 اسماً ومعانيها الجليلة' },
    { id: 'hadith' as TabType, label: 'الأحاديث الصحيحة', icon: BookOpen, desc: 'البخاري ومسلم والأربعون النووية' },
    { id: 'qibla' as TabType, label: 'اتجاه القبلة', icon: Compass, desc: 'بوصلة الكعبة المشرفة' },
    { id: 'calendar' as TabType, label: 'التقويم الهجري', icon: Calendar, desc: 'المناسبات والأعياد الإسلامية' },
    { id: 'about' as TabType, label: 'حول التطبيق', icon: Info, desc: 'Made by KASSOUANI YT' },
  ];

  const isMoreActive = moreNavItems.some(item => item.id === activeTab);

  const handleSelectMoreTab = (tab: TabType) => {
    setActiveTab(tab);
    setShowMoreMenu(false);
  };

  return (
    <>
      {/* More items drawer / overlay modal */}
      {showMoreMenu && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/60 backdrop-blur-xs animate-fade-in">
          <div
            className="flex-1"
            onClick={() => setShowMoreMenu(false)}
          />
          <div className="bg-white dark:bg-slate-900 border-t border-emerald-800/20 rounded-t-3xl p-5 shadow-2xl max-w-lg mx-auto w-full max-h-[80vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">الأقسام والخدمات الإسلامية</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">جميع الخدمات متاحة أوفلاين بدون إنترنت</p>
              </div>
              <button
                onClick={() => setShowMoreMenu(false)}
                className="p-1.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {moreNavItems.map((item) => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleSelectMoreTab(item.id)}
                    className={`flex flex-col items-start p-3 rounded-2xl text-right transition-all border ${
                      active
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-600 text-emerald-900 dark:text-emerald-300'
                        : 'bg-slate-50 dark:bg-slate-800/60 border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:border-emerald-300'
                    }`}
                  >
                    <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 flex items-center justify-center mb-2">
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-sm mb-0.5">{item.label}</span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">{item.desc}</span>
                  </button>
                );
              })}
            </div>

            <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span>نور الإسلام - Noor Al-Islam</span>
              <span className="font-semibold text-emerald-700 dark:text-emerald-400">Made by KASSOUANI YT</span>
            </div>
          </div>
        </div>
      )}

      {/* Main Bottom Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-emerald-900/10 dark:border-emerald-500/10 shadow-lg">
        <div className="max-w-md mx-auto px-3 py-1 flex items-center justify-around">
          {mainNavItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setShowMoreMenu(false);
                }}
                className={`flex flex-col items-center justify-center flex-1 py-1.5 transition-all relative ${
                  active
                    ? 'text-emerald-700 dark:text-emerald-400 font-bold scale-105'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 font-medium'
                }`}
              >
                <Icon className={`w-5 h-5 mb-0.5 ${active ? 'stroke-[2.5]' : 'stroke-2'}`} />
                <span className="text-[11px] leading-tight">{item.label}</span>
                {active && (
                  <span className="absolute bottom-0 w-8 h-1 bg-amber-500 rounded-full" />
                )}
              </button>
            );
          })}

          {/* More Sections Button */}
          <button
            onClick={() => setShowMoreMenu(!showMoreMenu)}
            className={`flex flex-col items-center justify-center flex-1 py-1.5 transition-all relative ${
              isMoreActive || showMoreMenu
                ? 'text-emerald-700 dark:text-emerald-400 font-bold scale-105'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 font-medium'
            }`}
          >
            <Grid className={`w-5 h-5 mb-0.5 ${isMoreActive || showMoreMenu ? 'stroke-[2.5]' : 'stroke-2'}`} />
            <span className="text-[11px] leading-tight">المزيد</span>
            {isMoreActive && (
              <span className="absolute bottom-0 w-8 h-1 bg-amber-500 rounded-full" />
            )}
          </button>
        </div>
      </nav>
    </>
  );
};
