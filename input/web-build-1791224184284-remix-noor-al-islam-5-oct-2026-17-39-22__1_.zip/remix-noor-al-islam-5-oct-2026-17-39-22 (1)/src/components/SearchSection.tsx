import React, { useState } from 'react';
import { 
  Search, 
  BookOpen, 
  HeartHandshake, 
  Sparkles, 
  Copy, 
  Check, 
  Bookmark, 
  Volume2,
  X 
} from 'lucide-react';
import { useApp, FavoriteItem } from '../context/AppContext';
import { ADHKAR_CATEGORIES } from '../data/adhkarData';
import { DUAS_CATEGORIES } from '../data/duasData';
import { NAMES_OF_ALLAH } from '../data/namesOfAllahData';
import { HADITHS_DATA } from '../data/hadithData';
import { soundEngine } from '../utils/audioTones';

const POPULAR_SEARCH_TAGS = [
  'الصباح',
  'المساء',
  'الرزق',
  'الاستغفار',
  'الوالدين',
  'الكرب',
  'الشفاء',
  'الصلاة',
  'النوم',
  'الجنة',
];

export const SearchSection: React.FC = () => {
  const { searchQuery, setSearchQuery, toggleFavorite, isFavorite, fontSize } = useApp();
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const query = searchQuery.trim().toLowerCase();

  // Search Results aggregations
  const adhkarResults = query
    ? ADHKAR_CATEGORIES.flatMap(cat =>
        cat.items
          .filter(it => it.arabic.toLowerCase().includes(query) || (it.virtue && it.virtue.toLowerCase().includes(query)))
          .map(it => ({ ...it, categoryName: cat.name }))
      )
    : [];

  const duasResults = query
    ? DUAS_CATEGORIES.flatMap(cat =>
        cat.items
          .filter(
            it =>
              it.title.toLowerCase().includes(query) ||
              it.arabic.toLowerCase().includes(query) ||
              (it.virtue && it.virtue.toLowerCase().includes(query))
          )
          .map(it => ({ ...it, categoryName: cat.name }))
      )
    : [];

  const namesResults = query
    ? NAMES_OF_ALLAH.filter(
        it =>
          it.name.toLowerCase().includes(query) ||
          it.meaning.toLowerCase().includes(query) ||
          it.explanation.toLowerCase().includes(query)
      )
    : [];

  const hadithResults = query
    ? HADITHS_DATA.filter(
        it =>
          it.title.toLowerCase().includes(query) ||
          it.arabic.toLowerCase().includes(query) ||
          it.narrator.toLowerCase().includes(query) ||
          it.source.toLowerCase().includes(query) ||
          it.explanation.toLowerCase().includes(query)
      )
    : [];

  const totalResults =
    adhkarResults.length + duasResults.length + namesResults.length + hadithResults.length;

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getFontSizeClass = () => {
    switch (fontSize) {
      case 'sm': return 'text-base';
      case 'md': return 'text-lg';
      case 'lg': return 'text-xl';
      case 'xl': return 'text-2xl';
    }
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* Search Input Box */}
      <div className="relative">
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="ابحث في الأذكار، الأدعية، أسماء الله، والأحاديث النبوية..."
          className="w-full bg-white dark:bg-slate-800/90 border-2 border-emerald-600/40 rounded-2xl py-3.5 pr-11 pl-10 text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:border-emerald-600 transition-colors shadow-sm"
          autoFocus
        />
        <Search className="w-5 h-5 text-emerald-600 absolute right-3.5 top-3.5" />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute left-3.5 top-3.5 p-1 rounded-full text-slate-400 hover:text-slate-600"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Suggested Search Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
        <span className="text-slate-400 font-medium shrink-0">مقترحات:</span>
        {POPULAR_SEARCH_TAGS.map((tag) => (
          <button
            key={tag}
            onClick={() => setSearchQuery(tag)}
            className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-emerald-400 shrink-0 transition-colors cursor-pointer"
          >
            {tag}
          </button>
        ))}
      </div>

      {/* Results Header or Idle State */}
      {!query ? (
        <div className="text-center py-16 bg-white dark:bg-slate-800/80 rounded-3xl p-6 border border-slate-100 dark:border-slate-800">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 flex items-center justify-center mx-auto mb-3">
            <Search className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
            البحث الإسلامي الشامل
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
            ابحث فوراً وبدون إنترنت في مئات الأذكار الصحيحة، الأدعية القرآنية والنبوية، أسماء الله الحسنى، والأحاديث النبوية.
          </p>
        </div>
      ) : totalResults === 0 ? (
        <div className="text-center py-12 bg-white dark:bg-slate-800/80 rounded-3xl p-6 border border-slate-100 dark:border-slate-800">
          <p className="text-sm font-bold text-slate-700 dark:text-slate-300 mb-1">
            لم يتم العثور على نتائج لـ «{searchQuery}»
          </p>
          <p className="text-xs text-slate-500">جرب البحث بكلمات أخرى مثل: دعاء، مغفرة، صباح، رسول الله</p>
        </div>
      ) : (
        <div className="space-y-5">
          <div className="flex items-center justify-between text-xs text-slate-500 px-1 font-medium">
            <span>تم العثور على {totalResults} نتيجة</span>
            <span>بحث أوفلاين فوري</span>
          </div>

          {/* Adhkar Results */}
          {adhkarResults.length > 0 && (
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1.5 px-1">
                <BookOpen className="w-3.5 h-3.5" />
                <span>نتائج الأذكار ({adhkarResults.length})</span>
              </h4>
              {adhkarResults.map((item) => (
                <div
                  key={item.id}
                  className="bg-white dark:bg-slate-800/90 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs"
                >
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-bold text-emerald-800 dark:text-emerald-300">
                      {item.categoryName}
                    </span>
                    <button
                      onClick={() => handleCopy(item.id, item.arabic)}
                      className="p-1 text-slate-400 hover:text-emerald-600"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-4 h-4 text-emerald-600 font-bold" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                  <p className={`font-amiri text-slate-900 dark:text-slate-100 leading-relaxed mb-2 ${getFontSizeClass()}`}>
                    {item.arabic}
                  </p>
                  <span className="text-[11px] text-slate-400 block">{item.source}</span>
                </div>
              ))}
            </div>
          )}

          {/* Duas Results */}
          {duasResults.length > 0 && (
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-teal-700 dark:text-teal-400 flex items-center gap-1.5 px-1">
                <HeartHandshake className="w-3.5 h-3.5" />
                <span>نتائج الأدعية ({duasResults.length})</span>
              </h4>
              {duasResults.map((item) => (
                <div
                  key={item.id}
                  className="bg-white dark:bg-slate-800/90 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs"
                >
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-bold text-slate-900 dark:text-white">{item.title}</span>
                    <button
                      onClick={() => handleCopy(item.id, item.arabic)}
                      className="p-1 text-slate-400 hover:text-emerald-600"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-4 h-4 text-emerald-600 font-bold" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                  <p className={`font-amiri text-slate-900 dark:text-slate-100 leading-relaxed mb-2 ${getFontSizeClass()}`}>
                    «{item.arabic}»
                  </p>
                  <span className="text-[11px] text-slate-400 block">{item.source}</span>
                </div>
              ))}
            </div>
          )}

          {/* Names of Allah Results */}
          {namesResults.length > 0 && (
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-amber-700 dark:text-amber-400 flex items-center gap-1.5 px-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>أسماء الله الحسنى ({namesResults.length})</span>
              </h4>
              <div className="grid grid-cols-2 gap-2">
                {namesResults.map((item) => (
                  <div
                    key={item.id}
                    className="bg-white dark:bg-slate-800/90 rounded-2xl p-3.5 border border-slate-100 dark:border-slate-800 shadow-xs"
                  >
                    <span className="text-xl font-bold font-amiri text-emerald-900 dark:text-amber-300 block mb-1">
                      {item.name}
                    </span>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                      {item.meaning}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Hadith Results */}
          {hadithResults.length > 0 && (
            <div className="space-y-2.5">
              <h4 className="text-xs font-bold text-blue-700 dark:text-blue-400 flex items-center gap-1.5 px-1">
                <BookOpen className="w-3.5 h-3.5" />
                <span>نتائج الأحاديث النبوية ({hadithResults.length})</span>
              </h4>
              {hadithResults.map((item) => (
                <div
                  key={item.id}
                  className="bg-white dark:bg-slate-800/90 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs"
                >
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="font-bold text-slate-900 dark:text-white">{item.title}</span>
                    <button
                      onClick={() => handleCopy(item.id, item.arabic)}
                      className="p-1 text-slate-400 hover:text-emerald-600"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-4 h-4 text-emerald-600 font-bold" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                  <p className={`font-amiri text-slate-900 dark:text-slate-100 leading-relaxed mb-2 ${getFontSizeClass()}`}>
                    {item.arabic}
                  </p>
                  <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-medium">
                    {item.source}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
