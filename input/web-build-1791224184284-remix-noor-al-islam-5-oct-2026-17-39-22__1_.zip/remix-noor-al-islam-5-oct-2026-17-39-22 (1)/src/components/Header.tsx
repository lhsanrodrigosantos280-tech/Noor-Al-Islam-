import React from 'react';
import { Search, Bookmark, Settings, Moon, Sun, Compass } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { getHijriDate } from '../data/hijriDate';

export const Header: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    isDarkMode,
    setIsDarkMode,
    hijriAdjustment,
    favorites,
  } = useApp();

  const hijri = getHijriDate(new Date(), hijriAdjustment);

  const getPageTitle = () => {
    switch (activeTab) {
      case 'home':
        return 'نور الإسلام';
      case 'adhkar':
        return 'حصن المسلم - الأذكار';
      case 'duas':
        return 'الأدعية المأثورة';
      case 'names':
        return 'أسماء الله الحسنى (99)';
      case 'hadith':
        return 'الأحاديث النبوية الصحيحة';
      case 'tasbih':
        return 'المسبحة الإلكترونية';
      case 'prayer':
        return 'مواقيت الصلاة';
      case 'qibla':
        return 'اتجاه القبلة';
      case 'calendar':
        return 'التقويم الهجري';
      case 'favorites':
        return 'المفضلة';
      case 'search':
        return 'البحث الشامل';
      case 'settings':
        return 'الإعدادات';
      case 'about':
        return 'حول التطبيق';
      default:
        return 'نور الإسلام';
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-emerald-900/95 dark:bg-emerald-950/95 backdrop-blur-md text-white border-b border-emerald-800/40 shadow-sm transition-colors">
      <div className="max-w-4xl mx-auto px-4 py-2.5 flex items-center justify-between">
        {/* Brand & Title */}
        <div
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2.5 cursor-pointer active:opacity-80 transition-opacity"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-300 flex items-center justify-center shadow-sm text-emerald-950">
            {/* Islamic Crescent and Star Icon */}
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10c2.58 0 4.93-.98 6.72-2.59-4.23-.42-7.56-4-7.56-8.41s3.33-7.99 7.56-8.41C16.93 2.98 14.58 2 12 2zm3.5 6.5l.8 1.8 1.9.3-1.4 1.3.3 1.9-1.6-1-1.6 1 .3-1.9-1.4-1.3 1.9-.3.8-1.8z" />
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-base md:text-lg font-bold tracking-tight text-amber-300">
                {activeTab === 'home' ? 'نور الإسلام' : getPageTitle()}
              </h1>
              {activeTab === 'home' && (
                <span className="text-[10px] bg-emerald-800/80 text-amber-200/90 px-1.5 py-0.5 rounded font-medium border border-emerald-700/60">
                  أوفلاين
                </span>
              )}
            </div>
            {activeTab === 'home' && (
              <p className="text-[11px] text-emerald-200/90 font-medium">
                {hijri.day} {hijri.monthName} {hijri.year} هـ
              </p>
            )}
          </div>
        </div>

        {/* Action Icons */}
        <div className="flex items-center gap-1 md:gap-2">
          {/* Qibla shortcut */}
          <button
            onClick={() => setActiveTab('qibla')}
            title="اتجاه القبلة"
            className={`p-2 rounded-xl transition-all ${
              activeTab === 'qibla'
                ? 'bg-amber-500 text-emerald-950 font-bold'
                : 'text-emerald-100 hover:bg-emerald-800/60 active:scale-95'
            }`}
          >
            <Compass className="w-5 h-5" />
          </button>

          {/* Search Button */}
          <button
            onClick={() => setActiveTab('search')}
            title="البحث"
            className={`p-2 rounded-xl transition-all ${
              activeTab === 'search'
                ? 'bg-amber-500 text-emerald-950 font-bold'
                : 'text-emerald-100 hover:bg-emerald-800/60 active:scale-95'
            }`}
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Favorites Button with Badge */}
          <button
            onClick={() => setActiveTab('favorites')}
            title="المفضلة"
            className={`relative p-2 rounded-xl transition-all ${
              activeTab === 'favorites'
                ? 'bg-amber-500 text-emerald-950 font-bold'
                : 'text-emerald-100 hover:bg-emerald-800/60 active:scale-95'
            }`}
          >
            <Bookmark className="w-5 h-5" />
            {favorites.length > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-amber-400 text-emerald-950 text-[10px] font-bold rounded-full flex items-center justify-center">
                {favorites.length}
              </span>
            )}
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            title={isDarkMode ? 'الوضع النهاري' : 'الوضع الليلي'}
            className="p-2 rounded-xl text-emerald-100 hover:bg-emerald-800/60 active:scale-95 transition-all"
          >
            {isDarkMode ? <Sun className="w-5 h-5 text-amber-300" /> : <Moon className="w-5 h-5" />}
          </button>

          {/* Settings Button */}
          <button
            onClick={() => setActiveTab('settings')}
            title="الإعدادات"
            className={`p-2 rounded-xl transition-all ${
              activeTab === 'settings'
                ? 'bg-amber-500 text-emerald-950 font-bold'
                : 'text-emerald-100 hover:bg-emerald-800/60 active:scale-95'
            }`}
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>
    </header>
  );
};
