import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  Bookmark, 
  Copy, 
  Check, 
  Share2, 
  Sparkles,
  Info
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { HADITH_CATEGORIES, HADITHS_DATA, HadithItem } from '../data/hadithData';

export const HadithSection: React.FC = () => {
  const { toggleFavorite, isFavorite, fontSize } = useApp();
  const [selectedCat, setSelectedCat] = useState<string>('all');
  const [query, setQuery] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredHadiths = HADITHS_DATA.filter((item) => {
    const matchesCat = selectedCat === 'all' || item.category === selectedCat;
    const q = query.trim().toLowerCase();
    if (!q) return matchesCat;
    const matchesSearch =
      item.title.toLowerCase().includes(q) ||
      item.arabic.toLowerCase().includes(q) ||
      item.narrator.toLowerCase().includes(q) ||
      item.source.toLowerCase().includes(q) ||
      item.explanation.toLowerCase().includes(q);
    return matchesCat && matchesSearch;
  });

  const handleCopy = (item: HadithItem) => {
    const text = `${item.title}\n\n«${item.arabic}»\n\nالراوي: ${item.narrator}\nالمصدر: ${item.source}\nالفوائد: ${item.explanation}\n\nتطبيق نور الإسلام`;
    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShare = (item: HadithItem) => {
    const text = `${item.title}\n\n«${item.arabic}»\n\nالراوي: ${item.narrator}\nالمصدر: ${item.source}\n\nتطبيق نور الإسلام - Made by KASSOUANI YT`;
    if (navigator.share) {
      navigator.share({ title: item.title, text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      alert('تم نسخ الحديث الشريف للمشاركة');
    }
  };

  const getFontSizeClass = () => {
    switch (fontSize) {
      case 'sm': return 'text-base';
      case 'md': return 'text-lg';
      case 'lg': return 'text-xl';
      case 'xl': return 'text-2xl';
    }
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-950 text-white rounded-3xl p-5 shadow-xs border border-emerald-700/50">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-amber-300 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-amber-400" />
              <span>الأحاديث النبوية الصحيحة</span>
            </h2>
            <p className="text-xs text-emerald-200/90 mt-1">
              مختارات من صحيحي البخاري ومسلم والأربعين النووية مع الشرح والفوائد
            </p>
          </div>
          <div className="bg-emerald-950/70 border border-emerald-600/50 rounded-2xl px-3 py-1.5 text-center">
            <span className="text-xl font-mono font-bold text-amber-300">{HADITHS_DATA.length}</span>
            <span className="text-[10px] text-emerald-200 block">حديثاً صحيحاً</span>
          </div>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
        {HADITH_CATEGORIES.map(cat => {
          const isActive = selectedCat === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCat(cat.id)}
              className={`px-3.5 py-2 rounded-2xl whitespace-nowrap text-xs font-bold transition-all shrink-0 cursor-pointer ${
                isActive
                  ? 'bg-emerald-800 text-amber-300 shadow-sm'
                  : 'bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border border-slate-100 dark:border-slate-800 hover:border-emerald-300'
              }`}
            >
              {cat.name}
            </button>
          );
        })}
      </div>

      {/* Search Input */}
      <div className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="ابحث في الأحاديث، الرواة، أو المعاني..."
          className="w-full bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-2xl py-2.5 pr-10 pl-4 text-xs md:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:border-emerald-600 transition-colors shadow-xs"
        />
        <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
        {query && (
          <button
            onClick={() => setQuery('')}
            className="absolute left-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
          >
            مسح
          </button>
        )}
      </div>

      {/* Hadiths Cards */}
      <div className="space-y-3.5">
        {filteredHadiths.length === 0 ? (
          <div className="text-center py-10 bg-white dark:bg-slate-800/80 rounded-3xl p-6 border border-slate-100 dark:border-slate-800">
            <p className="text-sm text-slate-500">لم يتم العثور على نتائج مطابقة لبحثك</p>
          </div>
        ) : (
          filteredHadiths.map((item, idx) => {
            const favorite = isFavorite(item.id);
            return (
              <div
                key={item.id}
                className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs hover:border-emerald-300 transition-all"
              >
                {/* Header */}
                <div className="flex items-center justify-between mb-3 pb-2.5 border-b border-slate-100 dark:border-slate-700/60">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-mono font-bold flex items-center justify-center text-xs">
                      #{idx + 1}
                    </span>
                    <h3 className="font-bold text-sm md:text-base text-slate-900 dark:text-white">
                      {item.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Copy */}
                    <button
                      onClick={() => handleCopy(item)}
                      title="نسخ الحديث"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-700 dark:hover:text-emerald-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-4 h-4 text-emerald-600 font-bold" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>

                    {/* Share */}
                    <button
                      onClick={() => handleShare(item)}
                      title="مشاركة"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-700 dark:hover:text-emerald-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>

                    {/* Favorite */}
                    <button
                      onClick={() =>
                        toggleFavorite({
                          id: item.id,
                          type: 'hadith',
                          title: item.title,
                          arabic: item.arabic,
                          source: `${item.source} • عن ${item.narrator}`,
                          extra: item.explanation,
                        })
                      }
                      title="إضافة للمفضلة"
                      className={`p-1.5 rounded-lg transition-colors ${
                        favorite
                          ? 'text-amber-500'
                          : 'text-slate-400 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-700'
                      }`}
                    >
                      <Bookmark className={`w-4 h-4 ${favorite ? 'fill-current' : ''}`} />
                    </button>
                  </div>
                </div>

                {/* Hadith Text */}
                <p className={`font-amiri leading-loose text-slate-900 dark:text-slate-100 text-justify mb-4 ${getFontSizeClass()}`}>
                  {item.arabic}
                </p>

                {/* Benefits / Explanation Box */}
                <div className="bg-slate-50 dark:bg-slate-700/40 rounded-2xl p-3.5 text-xs text-slate-700 dark:text-slate-300 border border-slate-100 dark:border-slate-700/50 mb-3">
                  <div className="flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400 font-bold mb-1">
                    <Info className="w-3.5 h-3.5" />
                    <span>من فوائد الحديث وهديه:</span>
                  </div>
                  <p className="leading-relaxed">{item.explanation}</p>
                </div>

                {/* Source & Narrator Footer */}
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-700/50">
                  <span className="font-semibold text-emerald-700 dark:text-emerald-400">
                    {item.source}
                  </span>
                  <span>الراوي: {item.narrator}</span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
