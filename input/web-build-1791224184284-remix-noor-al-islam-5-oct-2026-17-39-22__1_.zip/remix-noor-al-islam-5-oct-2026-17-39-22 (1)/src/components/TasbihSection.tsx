import React, { useState } from 'react';
import { 
  RotateCcw, 
  Volume2, 
  VolumeX, 
  Smartphone, 
  Plus, 
  Sparkles,
  Trophy,
  Sliders,
  Check
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { soundEngine } from '../utils/audioTones';

const DHIKR_PRESETS = [
  'سُبْحَانَ اللَّهِ',
  'الحَمْدُ لِلَّهِ',
  'لاَ إِلَهَ إِلاَّ اللَّهُ',
  'اللَّهُ أَكْبَرُ',
  'أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ',
  'لاَ حَوْلَ وَلاَ قُوَّةَ إِلاَّ بِاللَّهِ',
  'اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ',
  'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ العَظِيمِ',
  'حَسْبُنَا اللَّهُ وَنِعْمَ الوَكِيلُ',
  'لاَ إِلَهَ إِلاَّ أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ',
];

const TARGET_PRESETS = [33, 99, 100, 1000, 0]; // 0 = unlimited

export const TasbihSection: React.FC = () => {
  const {
    tasbihCount,
    tasbihTarget,
    tasbihTotal,
    tasbihLaps,
    tasbihDhikr,
    incrementTasbih,
    resetTasbihCurrent,
    resetTasbihAll,
    setTasbihTarget,
    setTasbihDhikr,
    soundEnabled,
    setSoundEnabled,
    vibrationEnabled,
    setVibrationEnabled,
  } = useApp();

  const [customDhikrInput, setCustomDhikrInput] = useState('');
  const [showCustomModal, setShowCustomModal] = useState(false);
  const [rippleAnim, setRippleAnim] = useState(false);

  const handleTap = () => {
    // Sound & Vibration
    if (soundEnabled) soundEngine.playBeadClick();
    if (vibrationEnabled) soundEngine.vibrate(35);

    // Ripple
    setRippleAnim(true);
    setTimeout(() => setRippleAnim(false), 200);

    const nextCount = tasbihCount + 1;
    if (tasbihTarget > 0 && nextCount >= tasbihTarget) {
      if (soundEnabled) soundEngine.playCompletionChime();
      if (vibrationEnabled) soundEngine.vibratePattern();
    }

    incrementTasbih();
  };

  const handleSaveCustomDhikr = (e: React.FormEvent) => {
    e.preventDefault();
    if (customDhikrInput.trim()) {
      setTasbihDhikr(customDhikrInput.trim());
      setCustomDhikrInput('');
      setShowCustomModal(false);
    }
  };

  // Progress percentage calculation
  const progressPercent = tasbihTarget > 0 ? Math.min(100, (tasbihCount / tasbihTarget) * 100) : 100;
  const strokeDashoffset = 565.48 - (565.48 * progressPercent) / 100; // circumference for r=90

  return (
    <div className="space-y-4 pb-20 animate-fade-in flex flex-col items-center">
      {/* Top Banner & Control Toggles */}
      <div className="w-full bg-white dark:bg-slate-800/90 rounded-3xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 flex items-center justify-center">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">المسبحة الإلكترونية</h2>
            <p className="text-[11px] text-slate-500">«ألا بذكر الله تطمئن القلوب»</p>
          </div>
        </div>

        {/* Sound & Vibration toggles */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            title={soundEnabled ? 'تعطيل الصوت' : 'تفعيل الصوت'}
            className={`p-2 rounded-xl border transition-all ${
              soundEnabled
                ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500/50 text-emerald-700 dark:text-emerald-300'
                : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-400'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            onClick={() => setVibrationEnabled(!vibrationEnabled)}
            title={vibrationEnabled ? 'تعطيل الاهتزاز' : 'تفعيل الاهتزاز'}
            className={`p-2 rounded-xl border transition-all ${
              vibrationEnabled
                ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-500/50 text-emerald-700 dark:text-emerald-300'
                : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-400'
            }`}
          >
            <Smartphone className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Target Selector Buttons */}
      <div className="w-full flex items-center justify-between gap-1.5 bg-white dark:bg-slate-800/90 p-1.5 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-xs">
        <span className="text-xs font-bold text-slate-500 pr-2">الهدف:</span>
        <div className="flex gap-1 flex-1 justify-end">
          {TARGET_PRESETS.map((t) => {
            const isActive = tasbihTarget === t;
            return (
              <button
                key={t}
                onClick={() => setTasbihTarget(t)}
                className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-emerald-800 text-amber-300 shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                {t === 0 ? 'مفتوح ∞' : t}
              </button>
            );
          })}
        </div>
      </div>

      {/* Current Dhikr Card */}
      <div className="w-full bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-950 rounded-3xl p-4 text-center text-white shadow-sm border border-emerald-700/50">
        <span className="text-[11px] text-emerald-200/90 font-medium block mb-1">الذكر الحالي</span>
        <h3 className="text-xl md:text-2xl font-bold font-amiri text-amber-300 leading-relaxed min-h-[48px] flex items-center justify-center">
          {tasbihDhikr}
        </h3>
      </div>

      {/* Big Tasbih Circular Tap Area */}
      <div className="relative my-4 flex items-center justify-center select-none">
        {/* SVG Circular Progress Ring */}
        <svg className="w-72 h-72 md:w-80 md:h-80 -rotate-90 transform" viewBox="0 0 200 200">
          {/* Background circle track */}
          <circle
            cx="100"
            cy="100"
            r="90"
            className="stroke-slate-200 dark:stroke-slate-800"
            strokeWidth="8"
            fill="none"
          />
          {/* Active progress track */}
          <circle
            cx="100"
            cy="100"
            r="90"
            className="stroke-amber-400 transition-all duration-150"
            strokeWidth="9"
            strokeDasharray="565.48"
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            fill="none"
          />
        </svg>

        {/* Central interactive counter button */}
        <button
          onClick={handleTap}
          className={`absolute w-56 h-56 md:w-64 md:h-64 rounded-full bg-gradient-to-b from-emerald-700 via-emerald-800 to-emerald-950 text-white shadow-xl flex flex-col items-center justify-center active:scale-95 transition-transform duration-100 border-4 border-emerald-600/40 cursor-pointer overflow-hidden ${
            rippleAnim ? 'ring-8 ring-amber-400/40' : ''
          }`}
        >
          {/* Subtle concentric rings for Islamic bead aesthetic */}
          <div className="absolute inset-4 rounded-full border border-emerald-500/20 pointer-events-none" />
          <div className="absolute inset-8 rounded-full border border-amber-400/10 pointer-events-none" />

          <span className="text-5xl md:text-6xl font-mono font-extrabold text-amber-300 tracking-wider">
            {tasbihCount}
          </span>
          <span className="text-xs text-emerald-200 font-medium mt-1">
            {tasbihTarget > 0 ? `الهدف: ${tasbihTarget}` : 'تسبيح حر'}
          </span>
          <span className="mt-3 px-3 py-1 rounded-full bg-emerald-900/80 text-[11px] text-amber-200/90 border border-emerald-600/40">
            اضغط هنا للتسبيح
          </span>
        </button>
      </div>

      {/* Stats and Reset Row */}
      <div className="w-full grid grid-cols-3 gap-2.5">
        {/* Completed Laps */}
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl p-3 border border-slate-100 dark:border-slate-800 text-center shadow-xs">
          <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">الدورات المكتملة</span>
          <span className="text-lg font-mono font-bold text-emerald-700 dark:text-emerald-400">{tasbihLaps}</span>
        </div>

        {/* Total Dhikrs */}
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl p-3 border border-slate-100 dark:border-slate-800 text-center shadow-xs">
          <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-0.5">المجموع الكلي</span>
          <span className="text-lg font-mono font-bold text-amber-600 dark:text-amber-400">{tasbihTotal}</span>
        </div>

        {/* Reset Actions */}
        <div className="flex gap-1">
          <button
            onClick={resetTasbihCurrent}
            title="تصفير الدورة الحالية"
            className="flex-1 flex flex-col items-center justify-center p-2 rounded-2xl bg-slate-100 dark:bg-slate-700/60 hover:bg-slate-200 text-slate-700 dark:text-slate-200 text-[10px] font-bold transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 mb-0.5 text-slate-500" />
            <span>تصفير الحالي</span>
          </button>
          <button
            onClick={resetTasbihAll}
            title="تصفير الكل"
            className="flex-1 flex flex-col items-center justify-center p-2 rounded-2xl bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-700 dark:text-rose-300 text-[10px] font-bold transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 mb-0.5 text-rose-500" />
            <span>تصفير الكل</span>
          </button>
        </div>
      </div>

      {/* Preset Dhikrs Carousel / List */}
      <div className="w-full bg-white dark:bg-slate-800/90 rounded-3xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">اختر ذكراً للتسبيح:</h4>
          <button
            onClick={() => setShowCustomModal(true)}
            className="flex items-center gap-1 text-xs text-emerald-700 dark:text-emerald-400 font-bold hover:underline"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>إضافة ذكر مخصص</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {DHIKR_PRESETS.map((d) => {
            const isCurrent = tasbihDhikr === d;
            return (
              <button
                key={d}
                onClick={() => setTasbihDhikr(d)}
                className={`p-3 rounded-2xl text-right transition-all text-xs font-amiri font-bold flex items-center justify-between cursor-pointer border ${
                  isCurrent
                    ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-600 text-emerald-950 dark:text-emerald-300'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:border-emerald-300'
                }`}
              >
                <span>{d}</span>
                {isCurrent && <Check className="w-4 h-4 text-emerald-600 shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Custom Dhikr Modal */}
      {showCustomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full p-5 text-right shadow-2xl border border-emerald-700/30">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">إضافة صيغة ذكر مخصصة</h3>
            <p className="text-xs text-slate-500 mb-4">اكتب الذكر أو الدعاء الذي تود التسبيح به</p>
            <form onSubmit={handleSaveCustomDhikr} className="space-y-4">
              <input
                type="text"
                value={customDhikrInput}
                onChange={(e) => setCustomDhikrInput(e.target.value)}
                placeholder="مثال: يَا حَيُّ يَا قَيُّومُ..."
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white font-amiri focus:outline-hidden focus:border-emerald-600"
                autoFocus
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 bg-emerald-800 hover:bg-emerald-700 text-white font-bold py-2 rounded-xl text-xs transition-colors"
                >
                  تعيين وبدء التسبيح
                </button>
                <button
                  type="button"
                  onClick={() => setShowCustomModal(false)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl text-xs"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
