import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, 
  Sparkles, 
  ChevronRight, 
  ChevronLeft, 
  Clock, 
  Settings2,
  BookmarkCheck
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { 
  getHijriDate, 
  ISLAMIC_EVENTS, 
  HIJRI_MONTHS, 
  ARABIC_DAYS 
} from '../data/hijriDate';

export const CalendarSection: React.FC = () => {
  const { hijriAdjustment, setHijriAdjustment } = useApp();
  const [selectedDate, setSelectedDate] = useState(new Date());

  const currentHijri = getHijriDate(selectedDate, hijriAdjustment);

  // Generate 29 or 30 days for this Hijri month
  const daysInMonth = 30;
  const monthDays = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* Hijri Banner */}
      <div className="bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-950 text-white rounded-3xl p-5 shadow-sm border border-emerald-700/50">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-400 text-emerald-950 flex items-center justify-center font-bold">
              <CalendarIcon className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-emerald-100">التقويم الهجري المبارك</h2>
              <span className="text-[11px] text-emerald-300">تقويم أم القرى المعتمد</span>
            </div>
          </div>

          {/* Hijri adjustment badge */}
          <div className="flex items-center gap-1 bg-emerald-950/70 border border-emerald-600/40 rounded-xl px-2 py-1 text-xs">
            <span className="text-slate-300">تعديل الرؤية:</span>
            <span className="font-bold text-amber-300 font-mono">
              {hijriAdjustment > 0 ? `+${hijriAdjustment}` : hijriAdjustment} يوم
            </span>
          </div>
        </div>

        {/* Big Date Display */}
        <div className="text-center my-3 py-3 border-y border-emerald-700/40">
          <span className="text-xs text-emerald-200/90 font-medium block mb-1">
            {currentHijri.gregorianFormatted}
          </span>
          <h3 className="text-3xl md:text-4xl font-black font-amiri text-amber-300">
            {currentHijri.formatted}
          </h3>
        </div>

        {/* Quick Date Adjustment Buttons */}
        <div className="flex items-center justify-center gap-2 pt-1 text-xs">
          <span className="text-emerald-200">ضبط حسب رؤية الهلال:</span>
          {[-2, -1, 0, 1, 2].map((adj) => (
            <button
              key={adj}
              onClick={() => setHijriAdjustment(adj)}
              className={`w-7 h-7 rounded-lg font-mono text-xs font-bold transition-all cursor-pointer ${
                hijriAdjustment === adj
                  ? 'bg-amber-400 text-emerald-950 shadow-xs'
                  : 'bg-emerald-800/80 text-emerald-100 hover:bg-emerald-700'
              }`}
            >
              {adj > 0 ? `+${adj}` : adj}
            </button>
          ))}
        </div>
      </div>

      {/* Month Days Grid Preview */}
      <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100 dark:border-slate-700/60">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <span>شهر {currentHijri.monthName} ({currentHijri.year} هـ)</span>
          </h3>
          <span className="text-xs bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 px-2 py-0.5 rounded-full font-medium">
            اليوم {currentHijri.day}
          </span>
        </div>

        {/* Grid of days in this month */}
        <div className="grid grid-cols-7 gap-1.5 text-center">
          {monthDays.map((d) => {
            const isToday = d === currentHijri.day;
            // Check if any Islamic event on this day of this month
            const eventOnDay = ISLAMIC_EVENTS.find(
              (e) => e.month === currentHijri.month && e.day === d
            );

            return (
              <div
                key={d}
                className={`py-2 px-1 rounded-xl text-xs font-mono font-bold transition-all relative flex flex-col items-center justify-center ${
                  isToday
                    ? 'bg-emerald-800 text-amber-300 shadow-sm scale-105'
                    : eventOnDay
                    ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-700'
                    : 'bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                }`}
                title={eventOnDay ? eventOnDay.title : undefined}
              >
                <span>{d}</span>
                {eventOnDay && (
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-0.5" />
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Islamic Events and Holy Occasions List */}
      <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs">
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100 dark:border-slate-700/60">
          <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <BookmarkCheck className="w-4 h-4 text-amber-500" />
            <span>المناسبات والأعياد الإسلامية</span>
          </h3>
          <span className="text-xs text-slate-400">على مدار العام</span>
        </div>

        <div className="space-y-2.5">
          {ISLAMIC_EVENTS.map((event, idx) => {
            const isCurrentMonth = event.month === currentHijri.month;
            return (
              <div
                key={idx}
                className={`p-3.5 rounded-2xl border transition-all flex items-start gap-3 ${
                  isCurrentMonth
                    ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-400 dark:border-emerald-800/60 shadow-xs'
                    : 'bg-slate-50 dark:bg-slate-800/50 border-slate-100 dark:border-slate-800'
                }`}
              >
                <div
                  className={`w-12 h-12 rounded-xl flex flex-col items-center justify-center shrink-0 ${
                    isCurrentMonth
                      ? 'bg-emerald-800 text-amber-300'
                      : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200'
                  }`}
                >
                  <span className="text-xs font-bold leading-none">{event.day}</span>
                  <span className="text-[10px] opacity-80 mt-0.5">{event.monthName}</span>
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-xs md:text-sm text-slate-900 dark:text-white">
                      {event.title}
                    </h4>
                    {isCurrentMonth && (
                      <span className="text-[10px] bg-emerald-200 dark:bg-emerald-900 text-emerald-900 dark:text-emerald-200 px-2 py-0.5 rounded-full font-bold">
                        هذا الشهر
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                    {event.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
