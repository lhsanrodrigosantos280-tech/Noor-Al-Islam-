import React from 'react';
import { 
  Sparkles, 
  Heart, 
  Share2, 
  ShieldCheck, 
  WifiOff, 
  CheckCircle2, 
  Code2, 
  Crown,
  Smartphone
} from 'lucide-react';

export const AboutSection: React.FC = () => {
  const handleShareApp = () => {
    if (navigator.share) {
      navigator.share({
        title: 'تطبيق نور الإسلام - Noor Al-Islam',
        text: 'تطبيق إسلامي شامل يعمل 100% بدون إنترنت (أوفلاين): أذكار، أدعية، أسماء الله الحسنى، أحاديث صحيحة، مواقيت الصلاة، والقبلة.\n\nMade by KASSOUANI YT',
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('تم نسخ رابط التطبيق إلى الحافظة');
    }
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* Brand Profile Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-950 text-white p-6 shadow-md border border-emerald-700/50 text-center">
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-500 to-amber-300 text-emerald-950 flex items-center justify-center mx-auto mb-3 shadow-lg">
          <svg className="w-12 h-12" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10c2.58 0 4.93-.98 6.72-2.59-4.23-.42-7.56-4-7.56-8.41s3.33-7.99 7.56-8.41C16.93 2.98 14.58 2 12 2zm3.5 6.5l.8 1.8 1.9.3-1.4 1.3.3 1.9-1.6-1-1.6 1 .3-1.9-1.4-1.3 1.9-.3.8-1.8z" />
          </svg>
        </div>

        <h2 className="text-2xl font-black text-amber-300">نور الإسلام</h2>
        <p className="text-xs text-emerald-200 font-mono tracking-wider mt-0.5">Noor Al-Islam • الإصدار 1.0.0</p>

        {/* Developer Credit Box */}
        <div className="mt-4 inline-flex items-center gap-2 bg-emerald-950/80 border border-amber-400/50 rounded-2xl px-4 py-2 shadow-inner">
          <Crown className="w-4 h-4 text-amber-400" />
          <span className="text-xs text-emerald-100">برمجة وتطوير:</span>
          <span className="text-sm font-extrabold text-amber-300 tracking-wide">
            Made by KASSOUANI YT
          </span>
        </div>
      </div>

      {/* Highlights & Guarantees */}
      <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-5 border border-slate-100 dark:border-slate-800 shadow-xs space-y-3.5">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>مميزات وخصائص التطبيق</span>
        </h3>

        <div className="grid grid-cols-1 gap-2.5 text-xs text-slate-700 dark:text-slate-300">
          <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/40">
            <WifiOff className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="block text-slate-900 dark:text-white mb-0.5">يعمل 100% بدون إنترنت (Offline):</strong>
              <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                جميع الأذكار، الأدعية، أسماء الله الحسنى، الأحاديث النبوية، ومواقيت الصلاة الفلكية مخزنة بالكامل على جهازك ولا تحتاج لأي اتصال بالإنترنت.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="block text-slate-900 dark:text-white mb-0.5">بدون حسابات أو تسجيل دخول:</strong>
              <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                خصوصية تامة، لا نطلب أي بيانات شخصية أو بريد إلكتروني، وكل محفوظاتك وإعداداتك تحفظ على جهازك بأمان.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
            <Smartphone className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <strong className="block text-slate-900 dark:text-white mb-0.5">تصميم إسلامي حديث وسريع:</strong>
              <p className="text-slate-500 dark:text-slate-400 leading-relaxed">
                واجهة عربية أصيلة تدعم الاتجاه من اليمين إلى اليسار (RTL)، مع خطوط عربية جميلة (الخط الأميري وخط تجوال)، ووضع داكن مريح.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Islamic Dua / Blessing Note */}
      <div className="bg-gradient-to-r from-amber-500/10 to-emerald-500/10 border border-amber-300/40 dark:border-amber-700/40 rounded-3xl p-5 text-center">
        <p className="font-amiri text-base md:text-lg text-emerald-950 dark:text-amber-200 leading-relaxed">
          «اللَّهُمَّ اجْعَلْ هَذَا العَمَلَ خَالِصاً لِوَجْهِكَ الكَرِيمِ، وَانْفَعْ بِهِ كُلَّ مَنْ قَرَأَهُ أَوْ نَشَرَهُ، وَاجْعَلْهُ فِي مِيزَانِ حَسَنَاتِنَا وَحَسَنَاتِ وَالِدِينَا وَجَمِيعِ المُسْلِمِينَ»
        </p>
        <span className="text-xs text-slate-500 dark:text-slate-400 block mt-2 font-medium">
          جزاكم الله خيراً ونفعنا وإياكم
        </span>
      </div>

      {/* Share Button */}
      <button
        onClick={handleShareApp}
        className="w-full bg-emerald-800 hover:bg-emerald-700 text-white font-bold py-3.5 rounded-2xl shadow-sm flex items-center justify-center gap-2 text-sm transition-all active:scale-98 cursor-pointer"
      >
        <Share2 className="w-4 h-4 text-amber-300" />
        <span>مشاركة التطبيق ولك الأجر بإذن الله</span>
      </button>

      {/* Footer copyright */}
      <div className="text-center pt-2 text-xs text-slate-400">
        جميع الحقوق محفوظة • Made by <strong className="text-emerald-700 dark:text-emerald-400">KASSOUANI YT</strong>
      </div>
    </div>
  );
};
