import React, { useState } from 'react';
import { 
  Sparkles, 
  Search, 
  Bookmark, 
  Volume2, 
  LayoutGrid, 
  List, 
  X,
  Share2
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { NAMES_OF_ALLAH, NameOfAllah } from '../data/namesOfAllahData';
import { soundEngine } from '../utils/audioTones';

export const NamesOfAllahSection: React.FC = () => {
  const { toggleFavorite, isFavorite } = useApp();
  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedName, setSelectedName] = useState<NameOfAllah | null>(null);

  const filteredNames = NAMES_OF_ALLAH.filter(item => {
    const q = search.trim().toLowerCase();
    return (
      item.name.toLowerCase().includes(q) ||
      item.meaning.toLowerCase().includes(q) ||
      item.transliteration.toLowerCase().includes(q) ||
      item.explanation.toLowerCase().includes(q) ||
      item.id.toString() === q
    );
  });

  const handleSpeak = (name: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    soundEngine.speakArabic(name);
  };

  const handleShareName = (item: NameOfAllah, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const text = `من أسماء الله الحسنى: ${item.name} (${item.transliteration})\n\nالمعنى: ${item.meaning}\n\nالشرح: ${item.explanation}\n\nتطبيق نور الإسلام - Made by KASSOUANI YT`;
    if (navigator.share) {
      navigator.share({ title: item.name, text }).catch(() => {});
    } else {
      navigator.clipboard.writeText(text);
      alert('تم نسخ اسم الله ومعناه');
    }
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-950 text-white rounded-3xl p-5 shadow-sm border border-emerald-700/50">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-amber-300 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <span>أسماء الله الحسنى (99 اسماً)</span>
            </h2>
            <p className="text-xs text-emerald-200/90 mt-1">
              قال رسول الله ﷺ: «إن لله تسعة وتسعين اسماً، مائة إلا واحداً، من أحصاها دخل الجنة»
            </p>
          </div>
          <div className="bg-emerald-950/70 border border-emerald-600/50 rounded-2xl px-3 py-1.5 text-center">
            <span className="text-xl font-mono font-bold text-amber-300">99</span>
            <span className="text-[10px] text-emerald-200 block">اسماً شريفاً</span>
          </div>
        </div>
      </div>

      {/* Search and Layout Toggle Bar */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث عن اسم أو معناه..."
            className="w-full bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 rounded-2xl py-2.5 pr-10 pl-4 text-xs md:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:border-emerald-600 transition-colors shadow-xs"
          />
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute left-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
            >
              مسح
            </button>
          )}
        </div>

        {/* View Toggle */}
        <div className="flex bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700 p-1 rounded-2xl">
          <button
            onClick={() => setViewMode('grid')}
            title="عرض شبكي"
            className={`p-2 rounded-xl transition-colors ${
              viewMode === 'grid'
                ? 'bg-emerald-800 text-amber-300'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <LayoutGrid className="w-4 h-4" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            title="عرض قائمة"
            className={`p-2 rounded-xl transition-colors ${
              viewMode === 'list'
                ? 'bg-emerald-800 text-amber-300'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <List className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Grid View */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2.5">
          {filteredNames.map((item) => {
            const favorite = isFavorite(`name-${item.id}`);
            return (
              <div
                key={item.id}
                onClick={() => setSelectedName(item)}
                className="bg-white dark:bg-slate-800/90 rounded-2xl p-3.5 border border-slate-100 dark:border-slate-800 hover:border-emerald-500/60 transition-all cursor-pointer shadow-xs hover:shadow-sm flex flex-col justify-between group active:scale-98"
              >
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="w-6 h-6 rounded-lg bg-emerald-50 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-mono font-bold flex items-center justify-center text-[10px]">
                    {item.id}
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => handleSpeak(item.name, e)}
                      title="استماع"
                      className="p-1 rounded text-slate-400 hover:text-emerald-600"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite({
                          id: `name-${item.id}`,
                          type: 'name',
                          title: item.name,
                          arabic: item.name,
                          source: item.transliteration,
                          extra: item.meaning,
                        });
                      }}
                      className={`p-1 rounded transition-colors ${
                        favorite ? 'text-amber-500' : 'text-slate-300 hover:text-amber-400'
                      }`}
                    >
                      <Bookmark className={`w-3.5 h-3.5 ${favorite ? 'fill-current' : ''}`} />
                    </button>
                  </div>
                </div>

                <div className="text-center my-2">
                  <h3 className="text-xl md:text-2xl font-bold font-amiri text-emerald-900 dark:text-amber-300 group-hover:scale-105 transition-transform">
                    {item.name}
                  </h3>
                  <span className="text-[10px] text-slate-400 font-sans block mt-0.5">
                    {item.transliteration}
                  </span>
                </div>

                <p className="text-[11px] text-slate-600 dark:text-slate-300 line-clamp-2 text-center mt-1 pt-1.5 border-t border-slate-100 dark:border-slate-700/50 leading-relaxed">
                  {item.meaning}
                </p>
              </div>
            );
          })}
        </div>
      ) : (
        /* List View */
        <div className="space-y-2.5">
          {filteredNames.map((item) => {
            const favorite = isFavorite(`name-${item.id}`);
            return (
              <div
                key={item.id}
                onClick={() => setSelectedName(item)}
                className="bg-white dark:bg-slate-800/90 rounded-2xl p-4 border border-slate-100 dark:border-slate-800 hover:border-emerald-500/60 transition-all cursor-pointer shadow-xs flex items-center justify-between gap-3 active:scale-99"
              >
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-mono font-bold flex items-center justify-center text-xs shrink-0">
                    {item.id}
                  </span>
                  <div>
                    <div className="flex items-baseline gap-2">
                      <h3 className="text-xl font-bold font-amiri text-emerald-900 dark:text-amber-300">
                        {item.name}
                      </h3>
                      <span className="text-xs text-slate-400">({item.transliteration})</span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-1 mt-0.5">
                      {item.meaning}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={(e) => handleSpeak(item.name, e)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-600 hover:bg-slate-100 dark:hover:bg-slate-700"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite({
                        id: `name-${item.id}`,
                        type: 'name',
                        title: item.name,
                        arabic: item.name,
                        source: item.transliteration,
                        extra: item.meaning,
                      });
                    }}
                    className={`p-1.5 rounded-lg transition-colors ${
                      favorite ? 'text-amber-500' : 'text-slate-300 hover:text-amber-400'
                    }`}
                  >
                    <Bookmark className={`w-4 h-4 ${favorite ? 'fill-current' : ''}`} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Name Details Modal */}
      {selectedName && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 text-right shadow-2xl border border-emerald-700/30">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <span className="text-xs font-mono font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 px-2.5 py-1 rounded-full">
                الاسم رقم #{selectedName.id}
              </span>
              <button
                onClick={() => setSelectedName(null)}
                className="p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Big Name Calligraphy */}
            <div className="text-center my-5 py-4 bg-gradient-to-b from-emerald-50 to-transparent dark:from-emerald-950/30 rounded-2xl">
              <h2 className="text-4xl md:text-5xl font-black font-amiri text-emerald-900 dark:text-amber-300 mb-1">
                {selectedName.name}
              </h2>
              <p className="text-sm font-medium text-slate-500">{selectedName.transliteration}</p>
            </div>

            {/* Meaning & Explanation */}
            <div className="space-y-3 mb-5">
              <div>
                <h4 className="text-xs font-bold text-emerald-700 dark:text-emerald-400 mb-1">المعنى والدلالة:</h4>
                <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl">
                  {selectedName.meaning}
                </p>
              </div>

              <div>
                <h4 className="text-xs font-bold text-amber-700 dark:text-amber-400 mb-1">الشرح والتأمل:</h4>
                <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed bg-amber-50/50 dark:bg-amber-950/20 p-3 rounded-2xl border border-amber-200/40 dark:border-amber-900/30">
                  {selectedName.explanation}
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => handleSpeak(selectedName.name)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200 text-xs font-bold"
              >
                <Volume2 className="w-4 h-4" />
                <span>استماع</span>
              </button>

              <button
                onClick={() => handleShareName(selectedName)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold"
              >
                <Share2 className="w-4 h-4" />
                <span>مشاركة</span>
              </button>

              <button
                onClick={() => setSelectedName(null)}
                className="flex-1 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white text-xs font-bold transition-colors"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
