import React, { useState, useEffect } from 'react';
import { 
  Check, 
  RotateCcw, 
  Bookmark, 
  Copy, 
  Volume2, 
  Sparkles, 
  Sun, 
  Moon, 
  Bed, 
  Sunrise, 
  Clock, 
  Shield 
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ADHKAR_CATEGORIES, DhikrItem } from '../data/adhkarData';
import { soundEngine } from '../utils/audioTones';

const categoryIcons: Record<string, React.ElementType> = {
  morning: Sun,
  evening: Moon,
  sleep: Bed,
  waking: Sunrise,
  prayer: Clock,
  daily: Shield,
};

export const AdhkarSection: React.FC = () => {
  const { 
    targetCategory, 
    setTargetCategory, 
    toggleFavorite, 
    isFavorite,
    soundEnabled,
    vibrationEnabled,
    fontSize
  } = useApp();

  const [activeCategoryId, setActiveCategoryId] = useState<string>(
    targetCategory || 'morning'
  );

  // Per-item completed counts state stored in component state or session
  const [itemProgress, setItemProgress] = useState<Record<string, number>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    if (targetCategory) {
      setActiveCategoryId(targetCategory);
      setTargetCategory(undefined);
    }
  }, [targetCategory, setTargetCategory]);

  const activeCategory = ADHKAR_CATEGORIES.find(c => c.id === activeCategoryId) || ADHKAR_CATEGORIES[0];

  const handleTapDhikr = (item: DhikrItem) => {
    const current = itemProgress[item.id] || 0;
    if (current < item.count) {
      const next = current + 1;
      setItemProgress(prev => ({ ...prev, [item.id]: next }));

      if (soundEnabled) soundEngine.playBeadClick();
      if (vibrationEnabled) soundEngine.vibrate(30);

      // Reached completion
      if (next === item.count) {
        if (soundEnabled) soundEngine.playCompletionChime();
        if (vibrationEnabled) soundEngine.vibratePattern();
      }
    }
  };

  const resetCategoryProgress = () => {
    const newProgress = { ...itemProgress };
    activeCategory.items.forEach(it => {
      newProgress[it.id] = 0;
    });
    setItemProgress(newProgress);
  };

  const handleCopy = (item: DhikrItem) => {
    const text = `${item.arabic}\n\nعدد المرات: ${item.count}\nالمصدر: ${item.source}${item.virtue ? `\nالفضل: ${item.virtue}` : ''}\n\nنور الإسلام`;
    navigator.clipboard.writeText(text);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (text: string) => {
    soundEngine.speakArabic(text);
  };

  // Calculate completed count in active category
  const completedCount = activeCategory.items.filter(it => (itemProgress[it.id] || 0) >= it.count).length;
  const totalCount = activeCategory.items.length;
  const progressPercent = Math.round((completedCount / totalCount) * 100);

  const getFontSizeClass = () => {
    switch (fontSize) {
      case 'sm': return 'text-base';
      case 'md': return 'text-lg';
      case 'lg': return 'text-xl';
      case 'xl': return 'text-2xl';
    }
  };

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* Category Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1.5 scrollbar-none">
        {ADHKAR_CATEGORIES.map(cat => {
          const Icon = categoryIcons[cat.id] || Sparkles;
          const isActive = activeCategoryId === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategoryId(cat.id)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl whitespace-nowrap text-xs font-bold transition-all shrink-0 cursor-pointer ${
                isActive
                  ? 'bg-emerald-800 text-amber-300 shadow-sm'
                  : 'bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border border-slate-100 dark:border-slate-800 hover:border-emerald-300'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{cat.name}</span>
            </button>
          );
        })}
      </div>

      {/* Category Header & Progress Card */}
      <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs flex flex-col gap-2.5">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>{activeCategory.name}</span>
              <span className="text-xs bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 px-2 py-0.5 rounded-full">
                {activeCategory.items.length} أذكار
              </span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {activeCategory.description}
            </p>
          </div>

          <button
            onClick={resetCategoryProgress}
            title="إعادة تعيين العدادات"
            className="flex items-center gap-1 text-xs text-slate-500 hover:text-emerald-700 dark:hover:text-emerald-400 bg-slate-100 dark:bg-slate-700/60 px-2.5 py-1.5 rounded-xl transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>تصفير</span>
          </button>
        </div>

        {/* Progress Bar */}
        <div>
          <div className="flex items-center justify-between text-xs font-semibold mb-1 text-slate-600 dark:text-slate-300">
            <span>نسبة الإتمام: {progressPercent}%</span>
            <span>{completedCount} من {totalCount}</span>
          </div>
          <div className="w-full h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-l from-amber-400 to-emerald-600 rounded-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      </div>

      {/* Dhikr Cards List */}
      <div className="space-y-3">
        {activeCategory.items.map((item, index) => {
          const currentTaps = itemProgress[item.id] || 0;
          const isDone = currentTaps >= item.count;
          const remaining = Math.max(0, item.count - currentTaps);
          const favorite = isFavorite(item.id);

          return (
            <div
              key={item.id}
              className={`rounded-3xl p-5 border transition-all ${
                isDone
                  ? 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800/60 shadow-xs'
                  : 'bg-white dark:bg-slate-800/90 border-slate-100 dark:border-slate-800 shadow-xs hover:border-emerald-200'
              }`}
            >
              {/* Top Controls Bar */}
              <div className="flex items-center justify-between mb-3 text-xs">
                <span className="font-bold text-slate-400 dark:text-slate-500 font-mono">
                  #{index + 1}
                </span>

                <div className="flex items-center gap-1.5">
                  {/* Speak button */}
                  <button
                    onClick={() => handleSpeak(item.arabic)}
                    title="الاستماع للذكر"
                    className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-700 dark:hover:text-emerald-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>

                  {/* Copy button */}
                  <button
                    onClick={() => handleCopy(item)}
                    title="نسخ الذكر"
                    className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-700 dark:hover:text-emerald-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors relative"
                  >
                    {copiedId === item.id ? (
                      <Check className="w-4 h-4 text-emerald-600 font-bold" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>

                  {/* Favorite button */}
                  <button
                    onClick={() =>
                      toggleFavorite({
                        id: item.id,
                        type: 'dhikr',
                        title: activeCategory.name,
                        arabic: item.arabic,
                        source: item.source,
                        extra: item.virtue,
                      })
                    }
                    title="إضافة للمفضلة"
                    className={`p-1.5 rounded-lg transition-colors ${
                      favorite
                        ? 'text-amber-500'
                        : 'text-slate-400 hover:text-amber-500 hover:bg-slate-100 dark:hover:bg-slate-700'
                    }`}
                  >
                    <Bookmark className={`w-4 h-4 ${favorite ? 'fill-current' : ''}`} />
                  </button>
                </div>
              </div>

              {/* Arabic Content */}
              <p
                onClick={() => handleTapDhikr(item)}
                className={`font-amiri leading-loose text-slate-900 dark:text-slate-100 text-justify cursor-pointer select-none mb-3 ${getFontSizeClass()}`}
              >
                {item.arabic}
              </p>

              {/* Virtue & Source box */}
              {item.virtue && (
                <div className="bg-amber-50/80 dark:bg-amber-950/30 rounded-2xl p-3 text-xs text-amber-900 dark:text-amber-200 border border-amber-200/50 dark:border-amber-900/40 mb-3">
                  <span className="font-bold text-amber-800 dark:text-amber-300 block mb-0.5">فضل الذكر:</span>
                  <p className="leading-relaxed">{item.virtue}</p>
                </div>
              )}

              {/* Bottom Counter Bar */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                  المصدر: {item.source}
                </span>

                {/* Interactive Big Counter Button */}
                <button
                  onClick={() => handleTapDhikr(item)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-2xl font-bold text-xs transition-all active:scale-95 cursor-pointer shadow-sm ${
                    isDone
                      ? 'bg-emerald-600 text-white'
                      : 'bg-emerald-800 hover:bg-emerald-700 text-amber-300'
                  }`}
                >
                  {isDone ? (
                    <>
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>اكتمل ({item.count})</span>
                    </>
                  ) : (
                    <>
                      <span>اضغط للتسبيح</span>
                      <span className="bg-emerald-950/70 text-white font-mono px-2 py-0.5 rounded-lg text-xs">
                        {currentTaps}/{item.count}
                      </span>
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
