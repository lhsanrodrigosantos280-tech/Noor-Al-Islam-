import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  MapPin, 
  Navigation, 
  Settings2, 
  Sun, 
  Sunrise, 
  Sunset, 
  Moon, 
  Volume2, 
  Check, 
  ChevronDown, 
  Compass,
  Sparkles
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { 
  calculatePrayerTimes, 
  POPULAR_CITIES, 
  CALCULATION_METHODS, 
  CityPreset 
} from '../data/prayerCalc';
import { getHijriDate } from '../data/hijriDate';
import { soundEngine } from '../utils/audioTones';

export const PrayerSection: React.FC = () => {
  const {
    userLocation,
    setUserLocation,
    requestGpsLocation,
    prayerMethod,
    setPrayerMethod,
    asrMethod,
    setAsrMethod,
    hijriAdjustment,
    setActiveTab,
  } = useApp();

  const [now, setNow] = useState(new Date());
  const [showCityPicker, setShowCityPicker] = useState(false);
  const [showMethodModal, setShowMethodModal] = useState(false);
  const [isLocating, setIsLocating] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const hijri = getHijriDate(now, hijriAdjustment);
  const prayerResult = calculatePrayerTimes(
    now,
    userLocation.lat,
    userLocation.lng,
    userLocation.timezoneOffset,
    prayerMethod,
    asrMethod
  );

  const handleUseGps = async () => {
    setIsLocating(true);
    setGpsError(null);
    const success = await requestGpsLocation();
    setIsLocating(false);
    if (!success) {
      setGpsError('تعذر الحصول على الموقع الجغرافي. تأكد من تفعيل خدمة الموقع GPS في جهازك.');
      setTimeout(() => setGpsError(null), 5000);
    }
  };

  const handleSelectCity = (city: CityPreset) => {
    setUserLocation({
      name: city.name,
      country: city.country,
      lat: city.lat,
      lng: city.lng,
      isGps: false,
      timezoneOffset: city.timezoneOffset,
    });
    setPrayerMethod(city.defaultMethod);
    setShowCityPicker(false);
  };

  const prayers = [
    { key: 'fajr', name: 'الفجر', time: prayerResult.fajr, icon: Moon, desc: 'الصلاة خير من النوم' },
    { key: 'sunrise', name: 'الشروق', time: prayerResult.sunrise, icon: Sunrise, desc: 'وقت شروق الشمس وانتهاء الفجر' },
    { key: 'dhuhr', name: 'الظهر', time: prayerResult.dhuhr, icon: Sun, desc: 'أول صلاة صلاها النبي ﷺ' },
    { key: 'asr', name: 'العصر', time: prayerResult.asr, icon: Sun, desc: 'الصلاة الوسطى' },
    { key: 'maghrib', name: 'المغرب', time: prayerResult.maghrib, icon: Sunset, desc: 'وقت إفطار الصائم' },
    { key: 'isha', name: 'العشاء', time: prayerResult.isha, icon: Moon, desc: 'نهاية صلوات اليوم المكتوبة' },
  ];

  return (
    <div className="space-y-4 pb-20 animate-fade-in">
      {/* Location & GPS bar */}
      <div className="bg-white dark:bg-slate-800/90 rounded-3xl p-4 border border-slate-100 dark:border-slate-800 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 flex items-center justify-center">
            <MapPin className="w-4 h-4 text-emerald-700 dark:text-emerald-300" />
          </div>
          <div>
            <div className="flex items-center gap-1">
              <span className="font-bold text-sm text-slate-900 dark:text-white">
                {userLocation.name}
              </span>
              {userLocation.country && (
                <span className="text-xs text-slate-500">({userLocation.country})</span>
              )}
            </div>
            <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">
              {userLocation.isGps ? 'موقع دقيق عبر GPS' : 'حساب أوقات محلي أوفلاين'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={handleUseGps}
            disabled={isLocating}
            title="تحديد موقعي الآن"
            className="flex items-center gap-1 text-xs bg-emerald-800 hover:bg-emerald-700 text-amber-300 font-bold px-3 py-2 rounded-xl transition-all cursor-pointer shadow-xs disabled:opacity-50"
          >
            <Navigation className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
            <span>{isLocating ? 'جاري التحديد...' : 'موقعي'}</span>
          </button>

          <button
            onClick={() => setShowCityPicker(true)}
            title="اختيار مدينة"
            className="text-xs bg-slate-100 dark:bg-slate-700/60 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-medium px-2.5 py-2 rounded-xl transition-colors"
          >
            المدن
          </button>
        </div>
      </div>

      {gpsError && (
        <div className="bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-xs p-3 rounded-2xl border border-rose-200 dark:border-rose-900">
          {gpsError}
        </div>
      )}

      {/* Main Countdown Active Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-950 text-white p-6 shadow-md border border-emerald-700/40">
        <div className="flex items-start justify-between">
          <div>
            <span className="text-xs text-emerald-200/90 font-medium">
              {hijri.formatted}
            </span>
            <h2 className="text-2xl md:text-3xl font-black text-amber-300 mt-1">
              صلاة {prayerResult.nextPrayer.name}
            </h2>
            <p className="text-sm font-semibold text-emerald-100 mt-0.5">
              يحين الأذان عند الساعة {prayerResult.nextPrayer.timeStr}
            </p>
          </div>

          <div className="text-left bg-emerald-950/70 border border-emerald-600/40 rounded-2xl px-4 py-2.5 shadow-inner">
            <span className="text-[11px] text-emerald-300 block text-center mb-0.5">الوقت المتبقي</span>
            <span className="text-2xl md:text-3xl font-mono font-black text-amber-400">
              {prayerResult.nextPrayer.timeRemaining}
            </span>
          </div>
        </div>

        {/* Quick test adhan chime sound */}
        <div className="mt-4 pt-3 border-t border-emerald-700/40 flex items-center justify-between text-xs text-emerald-200">
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>طريقة الحساب: {CALCULATION_METHODS[prayerMethod]?.name || 'أم القرى'}</span>
          </div>
          <button
            onClick={() => setShowMethodModal(true)}
            className="text-amber-300 hover:underline font-bold flex items-center gap-1"
          >
            <Settings2 className="w-3.5 h-3.5" />
            <span>تعديل الطريقة</span>
          </button>
        </div>
      </div>

      {/* Prayers List */}
      <div className="space-y-2.5">
        {prayers.map((p) => {
          const isNext = prayerResult.nextPrayer.key === p.key;
          const Icon = p.icon;
          return (
            <div
              key={p.key}
              className={`p-4 rounded-3xl border transition-all flex items-center justify-between ${
                isNext
                  ? 'bg-emerald-800 text-white border-amber-400 shadow-md scale-101'
                  : 'bg-white dark:bg-slate-800/90 text-slate-800 dark:text-slate-100 border-slate-100 dark:border-slate-800 shadow-xs'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-11 h-11 rounded-2xl flex items-center justify-center ${
                    isNext
                      ? 'bg-amber-400 text-emerald-950'
                      : 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                  }`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-base">{p.name}</h3>
                    {isNext && (
                      <span className="text-[10px] bg-amber-400 text-emerald-950 px-2 py-0.5 rounded-full font-bold">
                        الصلاة القادمة
                      </span>
                    )}
                  </div>
                  <p
                    className={`text-xs mt-0.5 ${
                      isNext ? 'text-emerald-200' : 'text-slate-400 dark:text-slate-400'
                    }`}
                  >
                    {p.desc}
                  </p>
                </div>
              </div>

              <div className="text-left">
                <span
                  className={`text-xl md:text-2xl font-mono font-bold ${
                    isNext ? 'text-amber-300' : 'text-slate-900 dark:text-white'
                  }`}
                >
                  {p.time}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Qibla Direction Shortcut Banner */}
      <button
        onClick={() => setActiveTab('qibla')}
        className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 p-4 rounded-3xl shadow-sm flex items-center justify-between font-bold transition-all active:scale-99"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-slate-950/10 flex items-center justify-center">
            <Compass className="w-5 h-5 text-slate-950" />
          </div>
          <div className="text-right">
            <span className="text-sm block">تحقق من اتجاه القبلة الآن</span>
            <span className="text-[11px] font-normal opacity-90">بوصلة دقيقة نحو الكعبة المشرفة</span>
          </div>
        </div>
        <span className="text-xs bg-slate-950 text-white px-3 py-1.5 rounded-xl font-bold">
          فتح البوصلة
        </span>
      </button>

      {/* City Picker Modal */}
      {showCityPicker && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full p-5 text-right shadow-2xl border border-emerald-700/30 max-h-[85vh] flex flex-col">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">اختر مدينتك</h3>
            <p className="text-xs text-slate-500 mb-4">يتم حساب أوقات الصلاة أوفلاين بالكامل بدقة فلكية</p>

            <div className="overflow-y-auto space-y-2 flex-1 pr-1">
              {POPULAR_CITIES.map((c) => {
                const isCurrent = userLocation.name === c.name;
                return (
                  <button
                    key={c.name}
                    onClick={() => handleSelectCity(c)}
                    className={`w-full p-3 rounded-2xl text-right flex items-center justify-between transition-all border ${
                      isCurrent
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-600 text-emerald-950 dark:text-emerald-300 font-bold'
                        : 'bg-slate-50 dark:bg-slate-800/60 border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:border-emerald-300'
                    }`}
                  >
                    <div>
                      <span className="text-sm font-bold block">{c.name}</span>
                      <span className="text-xs text-slate-500">{c.country}</span>
                    </div>
                    {isCurrent && <Check className="w-5 h-5 text-emerald-600" />}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => setShowCityPicker(false)}
              className="mt-4 w-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-bold py-2.5 rounded-xl text-xs transition-colors"
            >
              إلغاء
            </button>
          </div>
        </div>
      )}

      {/* Method Settings Modal */}
      {showMethodModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-sm w-full p-5 text-right shadow-2xl border border-emerald-700/30">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">طريقة حساب مواقيت الصلاة</h3>
            <p className="text-xs text-slate-500 mb-4">اختر الهيئة أو المرجع الفلكي المعتمد في بلدك</p>

            <div className="space-y-2 mb-4">
              {Object.values(CALCULATION_METHODS).map((m) => {
                const isCurrent = prayerMethod === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => {
                      setPrayerMethod(m.id);
                    }}
                    className={`w-full p-3 rounded-2xl text-right flex items-center justify-between transition-all border ${
                      isCurrent
                        ? 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-600 text-emerald-950 dark:text-emerald-300 font-bold'
                        : 'bg-slate-50 dark:bg-slate-800/60 border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:border-emerald-300'
                    }`}
                  >
                    <span className="text-xs font-bold">{m.name}</span>
                    {isCurrent && <Check className="w-4 h-4 text-emerald-600" />}
                  </button>
                );
              })}
            </div>

            {/* Asr Juristic Method */}
            <div className="mb-4 pt-3 border-t border-slate-100 dark:border-slate-800">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block mb-2">مذهب صلاة العصر:</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setAsrMethod('standard')}
                  className={`p-2.5 rounded-xl text-xs font-bold border text-center transition-all ${
                    asrMethod === 'standard'
                      ? 'bg-emerald-800 text-amber-300 border-emerald-700'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  الجمهور (شافعي/مالكي/حنبلي)
                </button>
                <button
                  onClick={() => setAsrMethod('hanafi')}
                  className={`p-2.5 rounded-xl text-xs font-bold border text-center transition-all ${
                    asrMethod === 'hanafi'
                      ? 'bg-emerald-800 text-amber-300 border-emerald-700'
                      : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'
                  }`}
                >
                  الحنفي (ظل الشيء مثليه)
                </button>
              </div>
            </div>

            <button
              onClick={() => setShowMethodModal(false)}
              className="w-full bg-emerald-800 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-xl text-xs transition-colors"
            >
              حفظ الإعدادات
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
